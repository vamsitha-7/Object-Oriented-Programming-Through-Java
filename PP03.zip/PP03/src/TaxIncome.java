
public class TaxIncome implements Taxable{
	//1- this class implements the Taxable interface
	// 2- implement all the unimplemented abstract methods in the Taxable Interface, income tax is computed based on state and federal taxes 
	public TaxIncome() {
		
	}
	
	@Override
	public double compStateTax(double grossPay) {
		double stateTax = 0;
		stateTax = STATE_TAX * grossPay;
		return stateTax;
	}

	@Override
	public double compFederalTax(double grossPay) {
		double fedTax = 0;
		fedTax = FEDERAL_TAX * grossPay;
		return fedTax;
	}

	@Override
	public double compIncomeTax(double grossPay) {
		double stateTax = compStateTax(grossPay);
		double fedTax = compFederalTax(grossPay);
		double tax = stateTax + fedTax;
		return tax;
	}
}