

import java.util.Date;


public class PayPeriod {
	
	private int pID;
    private Date pStartDate, pEndDate;
    
    // 1- add the class constructor
    // 2- add the setters/getters methods
	// 3- add override method toString() 
    //Class Constructor
    public PayPeriod() {
    	
    }
    public PayPeriod(int id, Date sDate, Date eDate) {
    	this.pID = id;
    	this.pStartDate = sDate;
    	this.pEndDate = eDate;
    }

    
    //getters and setters
	public int getpID() {
		return pID;
	}

	public Date getpStartDate() {
		return pStartDate;
	}

	public Date getpEndDate() {
		return pEndDate;
	}

	

    //Override toString() method
	@Override
	public String toString() {
		return pID + "\t" + pStartDate + "\t" + pEndDate ;
	}
    
    
    
    
    
	

	
}
