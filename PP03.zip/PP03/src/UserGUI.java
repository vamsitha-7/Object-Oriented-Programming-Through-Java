

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class UserGUI extends JPanel implements ActionListener {

	private JLabel lblEId;
	private JLabel lblFName;
	private JLabel lblLName;
	private JLabel lblEmpStatus;
	private JLabel lblStreet;
	private JLabel lblHouseNum;
	private JLabel lblCity;
	private JLabel lblState;
	private JLabel lblZipCode;
	private JLabel lblPayPeriodId;
	private JLabel lblPStartDate;
	private JLabel lblPEndDate;
	private JLabel lblRecordId;
	private JLabel lblMonthlyIncome;
	private JLabel lblNumberMonths;
	private JLabel lblPayHours;
	private JLabel lblPayRate;
	private JLabel lblEmployeeHeader;
	private JLabel lblEmployeeAddressHeader;
	private JLabel lblPayPeriodHeader;
	private JLabel lblPayRecordHeader;
	private JLabel lblTextAreaHeader;

	private JTextField txtEId;
	private JTextField txtFName;
	private JTextField txtLName;
	private JTextField txtStreet;
	private JTextField txtHouseNum;
	private JTextField txtCity;
	private JTextField txtZipCode;
	private JTextField txtPayPeriodId;
	private JTextField txtPStartDate;
	private JTextField txtPEndDate;
	private JTextField txtRecordId;
	private JTextField txtMonthlyIncome;
	private JTextField txtNumberMonths;
	private JTextField txtPayHours;
	private JTextField txtPayRate;

	private JButton btnAddEmployee;
	private JButton btnAddPayRecord;
	private JButton btnClose;

	private JTextArea textArea;
	private JComboBox<String> cmbState;
	private JScrollPane jp;

	private JRadioButton rbtFullTime;
	private JRadioButton rbtHourly;
	private ButtonGroup rbtGroup;

	private final PayRoll payRoll;
	private final String fileName = "PayRoll.txt";
	
	private boolean newEmployeeAdded;


	public UserGUI() {

		int n= Integer.parseInt(JOptionPane.showInputDialog("Enter number of Pay Records"));

		payRoll = new PayRoll(fileName, n);

		payRoll.readFromFile();

		initGUI();
		doTheLayout();

		this.btnAddEmployee.addActionListener(this);
		this.btnAddPayRecord.addActionListener(this);
		this.btnClose.addActionListener(this);

		this.rbtFullTime.addActionListener(this);
		this.rbtHourly.addActionListener(this);
		
		this.newEmployeeAdded = false;
		
		
		updateTextArea();
		payRoll.writeToFile();

	} // end of constructor

	private void initGUI() {

		// labels
		this.lblEId = new JLabel("ID");
		this.lblFName = new JLabel("First Name");
		this.lblLName = new JLabel("Last Name");
		this.lblEmpStatus = new JLabel("Employee Status");
		this.lblStreet = new JLabel("Street");
		this.lblHouseNum = new JLabel("H/Apt Number");
		this.lblCity = new JLabel("City");
		this.lblState = new JLabel("State");
		this.lblZipCode = new JLabel("Zip Code");
		this.lblPayPeriodId = new JLabel("ID");
		this.lblPStartDate = new JLabel("Start Date");
		this.lblPEndDate = new JLabel("End Date");
		this.lblRecordId = new JLabel("ID");
		this.lblMonthlyIncome = new JLabel("Monthly Income");
		this.lblNumberMonths = new JLabel("Number of Months");
		this.lblPayHours = new JLabel("Pay Hours");
		this.lblPayRate = new JLabel("Pay Rate");

		this.lblEmployeeHeader = new JLabel("Employee");
		this.lblEmployeeHeader.setForeground(Color.black);
		this.lblEmployeeAddressHeader = new JLabel("Employee Address");
		// this.lblEmployeeHeader.setForeground(Color.black);
		this.lblPayPeriodHeader = new JLabel("Pay Period");
		this.lblPayPeriodHeader.setForeground(Color.black);
		this.lblPayRecordHeader = new JLabel("Pay Record");
		this.lblPayRecordHeader.setForeground(Color.black);
		this.lblTextAreaHeader = new JLabel("Pay Records and Statistics (Total and Average Pay)");
		this.lblTextAreaHeader.setForeground(Color.black);

		// textfields
		this.txtEId = new JTextField(5);
		this.txtFName = new JTextField(10);
		this.txtLName = new JTextField(10);
		this.txtStreet = new JTextField(10);
		this.txtHouseNum = new JTextField(5);
		this.txtCity = new JTextField(10);
		this.txtZipCode = new JTextField(5);
		this.txtPayPeriodId = new JTextField(5);
		this.txtPStartDate = new JTextField(10);
		this.txtPEndDate = new JTextField(10);
		this.txtRecordId = new JTextField(5);
		this.txtMonthlyIncome = new JTextField(5);
		this.txtNumberMonths = new JTextField(5);
		this.txtPayHours = new JTextField(5);
		this.txtPayRate = new JTextField(5);
		
		this.txtPayHours.setEditable(false);
		this.txtPayHours.setBackground(Color.black);
		this.txtPayRate.setEditable(false);
		this.txtPayRate.setBackground(Color.black);
		// textarea
		this.textArea = new JTextArea(5, 50);
		this.textArea.setEditable(false);

		this.jp = new JScrollPane(textArea);
		this.jp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		this.jp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

		// combobox
		final String[] states = {"", "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut",
				"Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas",
				"Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi",
				"Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York",
				"North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island",
				"South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington",
				"West Virginia", "Wisconsin", "Wyoming" };
		this.cmbState = new JComboBox<String>(states);
		this.cmbState.setSelectedIndex(0);

		// radio button
		this.rbtFullTime = new JRadioButton("Full Time", true);
		this.rbtFullTime.setActionCommand("FULLTIME");
		this.rbtHourly = new JRadioButton("Hourly");
		this.rbtHourly.setActionCommand("HOURLY");

		this.rbtGroup = new ButtonGroup();
		this.rbtGroup.add(this.rbtFullTime);
		this.rbtGroup.add(this.rbtHourly);

		// buttons
		this.btnAddEmployee = new JButton("Add Employee");
		this.btnAddEmployee.setForeground(Color.black);

		this.btnClose = new JButton("Close");
		this.btnClose.setForeground(Color.black);

		this.btnAddPayRecord = new JButton("Add Pay Record");
		this.btnAddPayRecord.setForeground(Color.black);

	}// end of creating objects method

	private void doTheLayout() {

		final JPanel top = new JPanel();
		final JPanel topTop = new JPanel();
		final JPanel topTop1 = new JPanel();
		final JPanel topTop2 = new JPanel();
		final JPanel topTop3 = new JPanel();
		final JPanel topCenter = new JPanel();
		final JPanel topCenter1 = new JPanel();
		final JPanel topCenter2 = new JPanel();
		final JPanel topCenter3 = new JPanel();
		final JPanel topBottom = new JPanel();
		final JPanel center = new JPanel();
		final JPanel centerTop = new JPanel();
		final JPanel centerTop1 = new JPanel();
		final JPanel centerTop2 = new JPanel();
		final JPanel centerCenter = new JPanel();
		final JPanel centerCenter1 = new JPanel();
		final JPanel centerCenter2 = new JPanel();
		final JPanel centerCenter3 = new JPanel();
		final JPanel centerCenter4 = new JPanel();
		final JPanel centerBottom = new JPanel();
		final JPanel bottom = new JPanel();
		final JPanel bottom1 = new JPanel();
		final JPanel bottom2 = new JPanel();
		final JPanel bottom3 = new JPanel();
		final JPanel centerAndBottom = new JPanel();

		topTop1.setLayout(new FlowLayout(FlowLayout.LEFT));
		topTop1.add(this.lblEmployeeHeader);

		topTop2.setLayout(new FlowLayout());
		topTop2.add(this.lblEId);
		topTop2.add(this.txtEId);
		topTop2.add(this.lblFName);
		topTop2.add(this.txtFName);
		topTop2.add(this.lblLName);
		topTop2.add(this.txtLName);

		topTop3.setLayout(new FlowLayout());
		topTop3.add(this.lblEmpStatus);
		topTop3.add(this.rbtFullTime);
		topTop3.add(this.rbtHourly);

		topTop.setLayout(new GridLayout(3, 1));
		topTop.add(topTop1);
		topTop.add(topTop2);
		topTop.add(topTop3);

		

		topCenter1.setLayout(new FlowLayout(FlowLayout.LEFT));
		topCenter1.add(this.lblEmployeeAddressHeader);

		topCenter2.setLayout(new FlowLayout());
		topCenter2.add(this.lblStreet);
		topCenter2.add(this.txtStreet);
		topCenter2.add(this.lblHouseNum);
		topCenter2.add(this.txtHouseNum);
		topCenter2.add(this.lblCity);
		topCenter2.add(this.txtCity);

		topCenter3.setLayout(new FlowLayout());
		topCenter3.add(this.lblState);
		topCenter3.add(this.cmbState);
		topCenter3.add(this.lblZipCode);
		topCenter3.add(this.txtZipCode);

		topCenter.setLayout(new GridLayout(3, 1));
		topCenter.add(topCenter1);
		topCenter.add(topCenter2);
		topCenter.add(topCenter3);

		topBottom.setLayout(new FlowLayout());
		topBottom.add(this.btnAddEmployee);

		top.setLayout(new BorderLayout());
		top.add(topTop, BorderLayout.NORTH);
		top.add(topCenter, BorderLayout.CENTER);
		top.add(topBottom, BorderLayout.SOUTH);

		centerTop1.setLayout(new FlowLayout(FlowLayout.LEADING));
		centerTop1.add(this.lblPayPeriodHeader);

		centerTop2.setLayout(new FlowLayout());
		centerTop2.add(this.lblPayPeriodId);
		centerTop2.add(this.txtPayPeriodId);
		centerTop2.add(this.lblPStartDate);
		centerTop2.add(this.txtPStartDate);
		centerTop2.add(this.lblPEndDate);
		centerTop2.add(this.txtPEndDate);

		centerTop.setLayout(new GridLayout(2, 1));
		centerTop.add(centerTop1);
		centerTop.add(centerTop2);

		centerCenter1.setLayout(new FlowLayout(FlowLayout.LEADING));
		centerCenter1.add(this.lblPayRecordHeader);

		centerCenter2.setLayout(new FlowLayout());
		centerCenter2.add(this.lblRecordId);
		centerCenter2.add(this.txtRecordId);

		centerCenter3.setLayout(new FlowLayout());
		centerCenter3.add(this.lblMonthlyIncome);
		centerCenter3.add(this.txtMonthlyIncome);
		centerCenter3.add(this.lblNumberMonths);
		centerCenter3.add(this.txtNumberMonths);

		centerCenter4.setLayout(new FlowLayout());
		centerCenter4.add(this.lblPayHours);
		centerCenter4.add(this.txtPayHours);
		centerCenter4.add(this.lblPayRate);
		centerCenter4.add(this.txtPayRate);

		centerCenter.setLayout(new GridLayout(4, 1));
		centerCenter.add(centerCenter1);
		centerCenter.add(centerCenter2);
		centerCenter.add(centerCenter3);
		centerCenter.add(centerCenter4);

		centerBottom.setLayout(new FlowLayout());
		centerBottom.add(this.btnAddPayRecord);

		center.setLayout(new BorderLayout());
		center.add(centerTop, BorderLayout.NORTH);
		center.add(centerCenter, BorderLayout.CENTER);
		center.add(centerBottom, BorderLayout.SOUTH);

		bottom1.setLayout(new GridLayout(2, 1));
		bottom1.add(this.lblTextAreaHeader);
		bottom1.add(this.jp);

		bottom3.setLayout(new FlowLayout());
		bottom3.add(this.btnClose);

		bottom.setLayout(new BorderLayout());
		bottom.add(bottom1, BorderLayout.NORTH);
		bottom.add(bottom3, BorderLayout.CENTER);


		this.add(top, BorderLayout.NORTH);
		this.add(center, BorderLayout.CENTER);
		this.add(bottom, BorderLayout.SOUTH);

	}// end of Layout method

	
	public void close() {
		System.exit(0);
	}

	public void addEmployee() {
		System.out.println("add employee clicked");
		int eID = 0;
		String fname = "";
		String lname = "";
		Status status = null;
		String street = "";
		int hNum = 0;
		String city = "";
		String state = "";
		int zipCode = 0;

		if (this.rbtFullTime.isSelected())
			status = this.payRoll.getStatusFromString(this.rbtFullTime.getActionCommand());
		else if (this.rbtHourly.isSelected())
			status = this.payRoll.getStatusFromString(this.rbtHourly.getActionCommand());


		try {
			eID = Integer.parseInt(this.txtEId.getText().trim());
			if (this.txtEId.getText().trim().equals(null) || this.txtEId.getText().trim() == "")
				throw new Exception();
			else if (this.txtEId.getText().trim().length() != 3)
				throw new Exception();
		} catch (final Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this.txtEId, "Invalid Number Format, Give atleast 3 Numbers in Id");
			this.txtEId.setText("");
			return;
		}

		if (!this.txtFName.getText().trim().matches("[A-Z][a-z]+")) {
			JOptionPane.showMessageDialog(this.txtFName, "Invalid Name Format, First Letter should be Capital");
			this.txtFName.setText("");
			return;
		}
		fname = this.txtFName.getText().trim();

		if (!this.txtLName.getText().trim().matches("[A-Z][a-z]+")) {
			JOptionPane.showMessageDialog(this.txtLName, "Invalid Name Format, First Letter Should be Capital");
			this.txtLName.setText("");
			return;
		}
		lname = this.txtLName.getText().trim();

		if (this.txtStreet.getText().trim().equalsIgnoreCase("")) {
			JOptionPane.showMessageDialog(this.txtStreet, "Cannot be Empty");
			return;
		}
		street = this.txtStreet.getText().trim();

		try {
			hNum = Integer.parseInt(this.txtHouseNum.getText().trim());
			if (this.txtHouseNum.getText().trim().equals(null) || this.txtHouseNum.getText().trim() == "")
				throw new Exception();

		} catch (final Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this.txtHouseNum, "Invalid Number Format, Give same Id!!");
			this.txtHouseNum.setText("");
			return;
		}

		if (!this.txtCity.getText().trim().matches("^[a-zA-Z ]+$")) {		
			JOptionPane.showMessageDialog(this.txtCity, "Cannot be Empty");
			return;
		}
		city = this.txtCity.getText().trim();
		

		if (this.cmbState.getSelectedItem().toString().trim().equalsIgnoreCase("")) {
			JOptionPane.showMessageDialog(this.cmbState, "Please select a state");
			return;
		}
		state = this.cmbState.getSelectedItem().toString().trim();

		try {
			zipCode = Integer.parseInt(this.txtZipCode.getText().trim());
			if (this.txtZipCode.getText().trim().equals(null) || this.txtZipCode.getText().trim() == "")
				throw new Exception();
			else if (this.txtZipCode.getText().trim().length() != 5)
				throw new Exception();
		} catch (final Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this.txtZipCode, "Invalid ZipCode Format, Need 5 Numbers");
			this.txtZipCode.setText("");
			return;
		}

		System.out.println("employee id = " + eID);
		System.out.println("employee status = " + status);
		System.out.println("employee fname = " + fname);
		System.out.println("employee lname = " + lname);
		System.out.println("employee street = " + street);
		System.out.println("employee house num = " + hNum);
		System.out.println("employee city = " + city);
		System.out.println("employee state = " + state);
		System.out.println("employee zipcode = " + zipCode);

		this.payRoll.createEmployee(eID, fname, lname, status, street, hNum, city, state, zipCode);

		JOptionPane.showMessageDialog(null, "Employee has been added succesfully. Please add PayRecord also.");

		this.btnAddEmployee.setEnabled(false);
		this.txtEId.setEditable(false);
		this.newEmployeeAdded = true;
		
		
	}

	public void addPayRecord() {
		
		if(!this.newEmployeeAdded) {

			JOptionPane.showMessageDialog(null, "Please add employee details first.");
			return;
			
		}
		
		System.out.println("add pay record clicked");
		Status status = null;
		int eID = 0;
		int periodId = 0;
		Date pStartDate = null;
		Date pEndDate = null;
		int recordId = 0;
		double monthlyIncome = 0;
		int numberMonths = 0;
		double payHours = 0;
		double payRate = 0;

		final SimpleDateFormat dateFormat = new SimpleDateFormat("MM/DD/YYYY");

		if (this.rbtFullTime.isSelected())
			status = this.payRoll.getStatusFromString(this.rbtFullTime.getActionCommand());
		else if (this.rbtHourly.isSelected())
			status = this.payRoll.getStatusFromString(this.rbtHourly.getActionCommand());

		try {
			eID = Integer.parseInt(this.txtEId.getText().trim());
			if (this.txtEId.getText().trim().equals(null) || this.txtEId.getText().trim() == "")
				throw new Exception();
			else if (this.txtEId.getText().trim().length() != 3)
				throw new Exception();
		} catch (final Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this.txtEId, "Invalid Number Format, Give Id is different , Give same ID!!");
			this.txtEId.setText("");
			return;
		}

		try {
			periodId = Integer.parseInt(this.txtPayPeriodId.getText().trim());
			if (this.txtPayPeriodId.getText().trim().equals(null) || this.txtPayPeriodId.getText().trim() == "")
				throw new Exception();
			else if (this.txtPayPeriodId.getText().trim().length() != 3)
				throw new Exception();
		} catch (final Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this.txtPayPeriodId, "Invalid Number Format, ID is Incorrect check again!");
			this.txtPayPeriodId.setText("");
			return;
		}

		try {
			if (this.txtPStartDate.getText().trim().equals(null) || this.txtPStartDate.getText().trim() == "")
				throw new Exception();
			else if (!this.txtPStartDate.getText().trim()
					.matches("^(0[1-9]|1[0-2])/(0[1-9]|1\\d|2\\d|3[01])/(19|20)\\d{2}$")) {
				JOptionPane.showMessageDialog(this.txtPStartDate, "Please enter the date in MM/DD/YYYY format");
				this.txtPStartDate.setText("");
				return;
			}
			pStartDate = dateFormat.parse(this.txtPStartDate.getText().trim());
		} catch (final ParseException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this.txtPStartDate, "Invalid Date Format - Parse Exception,Please enter a date in the format MM/DD/YYYY, where MM is a number from 01 to 12, DD is a number from 01 to 31, and YYYY is a four-digit year between 1900 and 2099.");
			this.txtPStartDate.setText("");
			return;
		} catch (final Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this.txtPStartDate, "Invalid Date Format - Exception,Please enter a date in the format MM/DD/YYYY, where MM is a number from 01 to 12, DD is a number from 01 to 31, and YYYY is a four-digit year between 1900 and 2099.");
			this.txtPStartDate.setText("");
			return;
		}

		try {
			if (this.txtPEndDate.getText().trim().equals(null) || this.txtPEndDate.getText().trim() == "")
				throw new Exception();
			else if (!this.txtPEndDate.getText().trim()
					.matches("^(0[1-9]|1[0-2])/(0[1-9]|1\\d|2\\d|3[01])/(19|20)\\d{2}$")) {
				JOptionPane.showMessageDialog(this.txtPEndDate, "Please enter the date in MM/DD/YYYY format,Please enter a date in the format MM/DD/YYYY, where MM is a number from 01 to 12, DD is a number from 01 to 31, and YYYY is a four-digit year between 1900 and 2099.");
				this.txtPEndDate.setText("");
				return;
			}
			pEndDate = dateFormat.parse(this.txtPEndDate.getText().trim());
		} catch (final ParseException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this.txtPEndDate, "Invalid Date Format - Parse Exception,Please enter a date in the format MM/DD/YYYY, where MM is a number from 01 to 12, DD is a number from 01 to 31, and YYYY is a four-digit year between 1900 and 2099.");
			this.txtPEndDate.setText("");
			return;
		} catch (final Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this.txtPEndDate, "Invalid Date Format - Exception,Please enter a date in the format MM/DD/YYYY, where MM is a number from 01 to 12, DD is a number from 01 to 31, and YYYY is a four-digit year between 1900 and 2099.");
			this.txtPEndDate.setText("");
			return;
		}

		try {
			recordId = Integer.parseInt(this.txtRecordId.getText().trim());
			if (this.txtRecordId.getText().trim().equals(null) || this.txtRecordId.getText().trim() == "")
				throw new Exception();
			else if (this.txtRecordId.getText().trim().length() != 3)
				throw new Exception();
		} catch (final Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this.txtRecordId, "Invalid Number Format");
			this.txtRecordId.setText("");
			return;
		}

		if(status.equals(Status.FullTime)) {
			try {
				monthlyIncome = Double.parseDouble(this.txtMonthlyIncome.getText().trim());
				if (status.equals(Status.FullTime) && (this.txtMonthlyIncome.getText().trim().equals(null)
						|| this.txtMonthlyIncome.getText().trim() == ""))
					throw new Exception();
				else if (monthlyIncome < 0 || !this.txtMonthlyIncome.getText().trim().matches("^\\d+(\\.\\d+)?$"))
					throw new Exception();
			} catch (final Exception e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(this.txtMonthlyIncome, "Invalid Number Format,Please enter a valid decimal number. Ensure that the number consists of digits, and if it includes a decimal point, make sure it is followed by one or more digits.");
				this.txtMonthlyIncome.setText("");
				return;
			}

			try {
				numberMonths = Integer.parseInt(this.txtNumberMonths.getText().trim());
				if (status.equals(Status.FullTime) && (this.txtNumberMonths.getText().trim().equals(null)
						|| this.txtNumberMonths.getText().trim() == ""))
					throw new Exception();
				else if (numberMonths < 0)
					throw new Exception();
			} catch (final Exception e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(this.txtNumberMonths, "Invalid Number Format,Please enter a valid decimal number. Ensure that the number consists of digits, and if it includes a decimal point, make sure it is followed by one or more digits.");
				this.txtNumberMonths.setText("");
				return;
			}
		}else if(status.equals(Status.Hourly)) {
			try {
				payHours = Double.parseDouble(this.txtPayHours.getText().trim());
				if (status.equals(Status.Hourly)
						&& (this.txtPayHours.getText().trim().equals(null) || this.txtPayHours.getText().trim() == ""))
					throw new Exception();
				else if (payHours < 0 || !this.txtPayHours.getText().trim().matches("^\\d+(\\.\\d+)?$"))
					throw new Exception();
			} catch (final Exception e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(this.txtPayHours, "Invalid Number Format,Please enter a valid decimal number. Ensure that the number consists of digits, and if it includes a decimal point, make sure it is followed by one or more digits.");
				this.txtPayHours.setText("");
				return;
			}

			try {
				payRate = Double.parseDouble(this.txtPayRate.getText().trim());
				if (status.equals(Status.Hourly)
						&& (this.txtPayRate.getText().trim().equals(null) || this.txtPayRate.getText().trim() == ""))
					throw new Exception();
				else if (payRate < 0 || !this.txtPayRate.getText().trim().matches("^\\d+(\\.\\d+)?$"))
					throw new Exception();
			} catch (final Exception e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(this.txtPayRate, "Invalid Number Format,Please enter a valid decimal number. Ensure that the number consists of digits, and if it includes a decimal point, make sure it is followed by one or more digits.");
				this.txtPayRate.setText("");
				return;
			}
		}
		

		

		System.out.println("employee periodId = " + periodId);
		System.out.println("employee pStartDate = " + pStartDate);
		System.out.println("employee pEndDate = " + pEndDate);
		System.out.println("employee recordId = " + recordId);
		System.out.println("employee monthlyIncome = " + monthlyIncome);
		System.out.println("employee numberMonths = " + numberMonths);
		System.out.println("employee payHours = " + payHours);
		System.out.println("employee payRate = " + payRate);

		this.payRoll.createPayRecord(recordId, eID, monthlyIncome, numberMonths, payHours, payRate, periodId,
				pStartDate, pEndDate, status);
				updateTextArea();
		payRoll.writeToFile();

		clearTextFields();
		this.btnAddEmployee.setEnabled(true);
		this.newEmployeeAdded = false;
		this.txtEId.setEditable(true);
		if( payRoll.getTotalRecords() == payRoll.getNumPayRecords())
		{
			JOptionPane.showMessageDialog(null, "Maximum number of Employees. Cannot add more");
			this.btnAddEmployee.setEnabled(false);
			this.btnAddPayRecord.setEnabled(false);
		}
		
		
	}
	public void clearTextFields() {
		this.txtEId.setText("");
		this.txtFName.setText("");
		this.txtLName.setText("");
		this.txtStreet.setText("");
		this.txtHouseNum.setText("");
		this.txtCity.setText("");;
		this.txtZipCode.setText("");
		this.txtPayPeriodId.setText("");
		this.txtPStartDate.setText("");
		this.txtPEndDate.setText("");
		this.txtRecordId.setText("");
		this.txtMonthlyIncome.setText("");
		this.txtNumberMonths.setText("");
		this.txtPayHours.setText("");
		this.txtPayRate.setText("");
		this.cmbState.setSelectedIndex(0);
		
	}
	public void rbtFullTimeClicked() {
		this.txtPayHours.setEditable(false);
		this.txtPayHours.setBackground(Color.black);
		this.txtPayRate.setEditable(false);
		this.txtPayRate.setBackground(Color.black);
		this.txtMonthlyIncome.setEditable(true);
		this.txtMonthlyIncome.setBackground(Color.WHITE);
		this.txtNumberMonths.setEditable(true);
		this.txtNumberMonths.setBackground(Color.WHITE);

	}
	public void rbtHourlyClicked() {
		this.txtPayHours.setEditable(true);
		this.txtPayHours.setBackground(Color.WHITE);
		this.txtPayRate.setEditable(true);
		this.txtPayRate.setBackground(Color.WHITE);
		this.txtMonthlyIncome.setEditable(false);
		this.txtMonthlyIncome.setBackground(Color.black);
		this.txtNumberMonths.setEditable(false);
		this.txtNumberMonths.setBackground(Color.black);

	}

	
	@Override
	public void actionPerformed(final ActionEvent e) {
		if (e.getSource() == this.btnClose) {
			close();
		} else if (e.getSource() == this.btnAddEmployee) {
			addEmployee();
		} else if (e.getSource() == this.btnAddPayRecord) {
			addPayRecord();
		} else if (e.getSource() == this.rbtFullTime) {
			rbtFullTimeClicked();
		} else if (e.getSource() == this.rbtHourly) {
			rbtHourlyClicked();
		}

	}
	void updateTextArea() {
		
		String output = this.payRoll.displayPayRecord();
		
		double total = this.payRoll.totalNetPay();
		double avg = this.payRoll.avgNetPay();
		
		output = output + "\n\nTotal Pay of all records = " + String.format("%.2f",total) ;
		output = output + "\n\nAverage Net Pay of all records = " + String.format("%.2f",avg);
		
		this.textArea.setText(output);
	}
	
	
	public static void main(final String[] args) {

		final JFrame f = new JFrame("Pay Roll");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		final Container contentPane = f.getContentPane();
		contentPane.add(new UserGUI());
		f.pack();
		f.setSize(800, 800);
		f.setVisible(true);


	}

}
