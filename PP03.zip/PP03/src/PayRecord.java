

public class PayRecord {

	private final int rID;
	private final Employee employee;
	private final PayPeriod payPeriod;
	private final TaxIncome payTax;
	private final double payHours;
	private final double payRate;
	private final double monthlyIncome;
	private final int numMonths;

	public static final int REG_HOURS = 40;
	public static final double OT_RATE = 1.25;

	// pay record constructor for hourly employee
	public PayRecord(final int id, final Employee e, final PayPeriod period, final double hours, final double rate) {

		this.rID = id;
		this.employee = e;
		this.payPeriod = period;
		this.payHours = hours;
		this.payRate = rate;
		this.monthlyIncome = 0;
		this.numMonths = 0;
		this.payTax = new TaxIncome();

	}

	// pay record constructor for full time employee
	public PayRecord(final int id, final Employee e, final PayPeriod period, final double mIncome, final int mNum) {

		this.rID = id;
		this.employee = e;
		this.payPeriod = period;
		this.payHours = 0;
		this.payRate = 0;
		this.monthlyIncome = mIncome;
		this.numMonths = mNum;
		this.payTax = new TaxIncome();

	}

	// 1- add setters and getters methods
	// 2- add override method toString()
	// 3- complete the code in the following methods: grossPay() and netPay()
	//getters and setters
	public int getrID() {
		return rID;
	}

	public Employee getEmployee() {
		return employee;
	}

	public PayPeriod getPayPeriod() {
		return payPeriod;
	}

	public TaxIncome getPayTax() {
		return payTax;
	}

	public double getPayHours() {
		return payHours;
	}

	public double getPayRate() {
		return payRate;
	}

	public double getMontlyIncome() {
		return monthlyIncome;
	}

	public int getNumMonths() {
		return numMonths;
	}

	public static int getRegHours() {
		return REG_HOURS;
	}

	public static double getOtRate() {
		return OT_RATE;
	}

	//Override toString() method
	public String toString() {
		final double grossPay = grossPay();
		final double incomeTax = this.payTax.compIncomeTax(grossPay);
		final double netPay = netPay();

		return rID + "\t" + employee.toString() + "\t" + payPeriod.toString() + "\t" + String.format("%.2f", payHours) + "\t" + String.format("%.2f", payRate) + "\t" +String.format("%.2f", monthlyIncome) 
				+ "\t\t" + numMonths + "\t\t" + String.format("%.2f", grossPay) + "\t" + String.format("%.2f", incomeTax) + "\t"+ String.format("%.2f", netPay);

	}

	public double grossPay() {

		double grossPay = 0;
		if (this.employee.empStatus().equals(Status.FullTime)) {
			grossPay = this.numMonths * this.monthlyIncome;
		} else if (this.employee.empStatus().equals(Status.Hourly)) {
			if (this.payHours <= PayRecord.REG_HOURS)
				grossPay = this.payHours * this.payRate; // number of hours * pay rate
			else
				grossPay = (PayRecord.REG_HOURS * this.payRate) + ((this.payHours - PayRecord.REG_HOURS) * this.payRate * PayRecord.OT_RATE);
		}

		return grossPay;
	}

	// complete the code in this method to compute the net pay of the employee after taxes (state and federal)
	public double netPay() {

		double netPay = 0;
		final double gPay = grossPay();
		netPay = gPay - this.payTax.compIncomeTax(gPay);
		return netPay;

	}

}
