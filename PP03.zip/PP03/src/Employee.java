

public class Employee extends Person {
	

	private int eID;
	private Status empStatus;
	// 1- The Employee class extends superclass Person
	// 2- add the subclass Employee constructor that calls the supper Person class constructor, you should provide input data for all parent class data fields
	// 3- add setters/getters methods
	// 4- add override toString() method that overrides toString() in the superclass Person
	public Employee() {
		super();
	}

	public Employee(final String fName, final String lName, final Address address, final int ID, final Status status) {
		super(fName, lName, address);
		this.eID = ID;
		this.empStatus = status;
	}
	  //getters and setters
	public int geteID() {
		return this.eID;
	}

	public void seteID(final int eId) {
		this.eID = eId;
	}

	public Status empStatus() {
		return this.empStatus;
	}

	public void setEmpStatus(final Status status) {
		this.empStatus = status;
	}

	   //Override toString() method
	@Override
	public String toString() {
		return eID + "\t" + fName + "\t" + lName + "\t" + address.toString() + "\t" 
				+ empStatus;
	}

}
