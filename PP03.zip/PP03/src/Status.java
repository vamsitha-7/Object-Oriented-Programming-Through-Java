

public enum Status {
	
	FullTime, Hourly

}
