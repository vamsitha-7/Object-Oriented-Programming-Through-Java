

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


import javax.swing.JOptionPane;


public class PayRoll {

	private final String fileName;
	private final PayRecord[] payRecords;

	private double totalNetPay;
	private double avgNetPay;

	private static int NUM_PAY_RECORDS = 0;
	private static int NUM_EMP = 0;
	
	private final int totalRecords;
	private final Employee[] employees;

	public PayRoll(final String fileName, final int n) {

		this.fileName = fileName;
		int numRecords = getFileLength(fileName);
		numRecords = numRecords + n;
		this.totalRecords = numRecords;
		this.payRecords = new PayRecord[numRecords];
		this.employees = new Employee[numRecords];
	}
	public int getNumPayRecords() {
		return PayRoll.NUM_PAY_RECORDS;
	}
	public int getTotalRecords() {
		return totalRecords;
	}

	
	public int getFileLength(final String filename) {

		final File file = new File(filename);
		Scanner sc = null;
		int countEmp = 0,countRec=0;
		try {
			sc = new Scanner(file);
			while (sc.hasNext()) {
				String line = sc.nextLine();
				if (line.startsWith("employee"))
					countEmp++;
				else if(line.startsWith("payRecord"))
					countRec++;
				
			}
			
				
		} catch (final FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			sc.close();
		}
		
		return countRec;
	}

	public void readFromFile() {
		File file = null;
		Scanner input = null;

		try {
			file = new java.io.File(fileName);
			input = new Scanner(file);

			while (input.hasNext()) {
				final String line = input.nextLine();

				final String[] record = line.split(",");


				final Employee emp = null;
				Status eStatus = null;
				final SimpleDateFormat dateFormat = new SimpleDateFormat("MM/DD/YYYY");

				if (line.startsWith("employee")) {
					eStatus = getStatusFromString(record[4].trim());
					createEmployee(Integer.parseInt(record[1].trim()), record[2].trim(), record[3].trim(), eStatus,
							record[5].trim(), Integer.parseInt(record[6].trim()), record[7].trim(), record[8].trim(),
							Integer.parseInt(record[9].trim()));
				} else if (line.startsWith("payRecord")) {
					
					if (line.contains("<m>") && line.contains("<n>")) {
						final Status s = Status.FullTime;
						createPayRecord(Integer.parseInt(record[1].trim()), Integer.parseInt(record[2].trim()),
								Double.parseDouble(record[3].trim().replace("<m>", "")),
								Integer.parseInt(record[4].trim().replace("<n>", "")), 0, 0,
								Integer.parseInt(record[5].trim()), dateFormat.parse(record[6].trim()),
								dateFormat.parse(record[7].trim()), s);

					} else if (line.contains("<h>") && line.contains("<r>")) {
						final Status s = Status.Hourly;
						createPayRecord(Integer.parseInt(record[1].trim()), Integer.parseInt(record[2].trim()), 0, 0,
								Double.parseDouble(record[3].trim().replace("<h>", "")),
								Double.parseDouble(record[4].trim().replace("<r>", "")),
								Integer.parseInt(record[5].trim()), dateFormat.parse(record[6].trim()),
								dateFormat.parse(record[7].trim()), s);
					}
				}
			}
		} catch (final FileNotFoundException e) {
			e.printStackTrace();

		} catch (final ParseException e) {
			e.printStackTrace();

		} finally {
			input.close();
			JOptionPane.showMessageDialog(null, "Done Reading Employee data from file " + fileName);
		}

	}

	public void writeToFile() {


		File file = new File("PayRecord.txt");

	    PrintWriter output = null;
		try {
			output = new PrintWriter(file);
	        for (int i = 0; i < PayRoll.NUM_PAY_RECORDS; i++) {
	            output.println(payRecords[i].toString().replace("\t", ","));
	        }
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} finally {
			if(output!=null)
				output.close();
		}
		

	    JOptionPane.showMessageDialog(null, "Done Writing Details to file PayRecord.txt");
	}
	public Status getStatusFromString(final String str) {
		for (final Status status : Status.values()) {
			if (status.name().equalsIgnoreCase(str)) {
				return status;
			}
		}
		return null; 
	}

	public void createEmployee(final int eID, final String fName, final String lName, final Status eStatus,
			final String street, final int houseNum, final String city, final String state, final int zipCode) {

		
		final Address address = new Address(street, houseNum, city, state, zipCode);
		final Employee emp = new Employee(fName, lName, address, eID, eStatus);
		employees[PayRoll.NUM_EMP] = emp;
		PayRoll.NUM_EMP++;

	}

	public void createPayRecord(final int rID, final int eID, final double mIncome, final int nMonths,
			final double payHours, final double rate, final int pID, final Date sDate, final Date eDate,
			final Status eStatus) {
		
		PayRecord pay = null;
		final Employee emp = searchEmployee(eID);
		final PayPeriod period = new PayPeriod(pID, sDate, eDate);

		if (eStatus.equals(Status.FullTime)) {
			pay = new PayRecord(rID, emp, period, mIncome, nMonths);
		} else if (eStatus.equals(Status.Hourly)) {
			pay = new PayRecord(rID, emp, period, payHours, rate);
		}

		payRecords[PayRoll.NUM_PAY_RECORDS] = pay;
		PayRoll.NUM_PAY_RECORDS++;
		
	}

	public Employee searchEmployee(final int eID) {
		Employee emp = null;
		for (int i = 0; i < PayRoll.NUM_EMP; i++) {
			if (employees[i].geteID() == eID)
				emp = employees[i];
		}
		return emp;
	}


	public String displayPayRecord() {

		String output = "Record ID\tEmployeeID\tFirst Name\tLast Name\tH.Number\tStreet\t\tCity\tState\tZipCode\tStatus\tPay Period ID\tStart Date\t\t\tEnd Date\t\t\t"
				+ "Pay Hours\tPay Rate\tMonthly Income\tNumber Months\tGross Pay\tIncome Tax\tNet Pay";
		
		for(int i=0; i < PayRoll.NUM_PAY_RECORDS; i++) {
			output = output + "\n" + this.payRecords[i].toString();
		}
		
		return output;
	}
	

	public double avgNetPay() {
		this.avgNetPay=0;

		if(PayRoll.NUM_PAY_RECORDS>0) {
			double total = this.totalNetPay();
			this.avgNetPay = total / PayRoll.NUM_PAY_RECORDS;
		}
		
		return this.avgNetPay;

	}
	
	public double totalNetPay() {
		this.totalNetPay=0;
		if(PayRoll.NUM_PAY_RECORDS>0) {
			for(int i=0; i < PayRoll.NUM_PAY_RECORDS; i++) {
				PayRecord pay = this.payRecords[i];
				double net = pay.netPay();
				this.totalNetPay = this.totalNetPay + net;
			}
			
		}
		return this.totalNetPay;
	}

	
}
