

import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class TicketTest {

	/*Array of Audience object*/
	static Audience[] audienceList;

	public static void main(String[] args) {

		/*Input variable declaration and initialization*/
		String name = "";
		int noOfAdvancedays = 0;
		int numberOfAudience = 0;
		//int status = 0;
		String studentID="";
		String ticketNumber = "";
		// Handling input for the number of audience
        boolean validAudience = false;
        while (!validAudience) {
            try {
                numberOfAudience = Integer.parseInt(JOptionPane.showInputDialog("Enter number of audience: "));
                if (numberOfAudience <= 0) {
                    throw new IllegalArgumentException("Number of audience must be a positive integer.");
                }
                validAudience = true;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid format. Please enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        audienceList = new Audience[numberOfAudience];

		/*Get number of audience and create the Audience array*/
		//
		//

		/*Loop over no of audience to create appropriate ticket objects*/
        for (int i = 0; i < numberOfAudience; i++) {
        	try {
                name = JOptionPane.showInputDialog("Enter audience name: ");
                if (name.matches(".*\\d.*") || name.trim().isEmpty()) {
                    throw new IllegalArgumentException("Invalid format for name.");
                }
                boolean validDays = false;
                while (!validDays) {
                    try {
                        String input = JOptionPane.showInputDialog("Enter number of days in advance: ");
                        noOfAdvancedays = Integer.parseInt(input);
                        if (noOfAdvancedays < 0) {
                            throw new IllegalArgumentException("Number of days cannot be negative.");
                        }
                        validDays = true;
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Invalid format. Please enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
                    } catch (IllegalArgumentException e) {
                        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }

            int isStudentOption = Integer.parseInt(JOptionPane.showInputDialog("Are you a student? (1 for Yes, 0 for No)"));
            if (isStudentOption != 0 && isStudentOption != 1) {
                throw new IllegalArgumentException("Invalid format for student option.");
            }
            boolean isStudent = (isStudentOption == 1);

            // Generate a random ticket number for each audience
            // Generate a random letter between A-Z
            char randomLetter = (char) ('A' + Math.random() * ('Z' - 'A' + 1));
            // Generate three random digits between 0-9
            int randomDigits = (int) (Math.random() * 1000);
            ticketNumber = String.format("%c%03d", randomLetter, randomDigits);

            if (noOfAdvancedays == 0) {
                addWalkupTicket(name, ticketNumber);
            } else {
                studentID = "";
                boolean isOnCampus = false;
                if (isStudent) {
                    studentID = JOptionPane.showInputDialog("Enter student ID: ");
                    if (!studentID.matches("\\d{9}")) {
                        throw new IllegalArgumentException("Student ID must be a 9-digit number.");
                    }
                    int isOnCampusOption = Integer.parseInt(JOptionPane.showInputDialog("Are you an on-campus student? (1 for Yes, 0 for No)"));
                    if (isOnCampusOption != 0 && isOnCampusOption != 1) {
                        throw new IllegalArgumentException("Invalid format for on-campus option.");
                    }
                    isOnCampus = (isOnCampusOption == 1);
                }

                if (isStudent && isOnCampus) {
                    addOncampusAdvanceTicket(name, ticketNumber, noOfAdvancedays, studentID);
                } else if (isStudent && !isOnCampus) {
                    addOffcampusAdvanceTicket(name, ticketNumber, noOfAdvancedays, studentID);
                } else {
                    addAdvancedTicket(name, ticketNumber, noOfAdvancedays);
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid format. Please enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
            i--; // Decrement i to repeat the input for the current audience
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            i--; // Decrement i to repeat the input for the current audience
        }
        //Fill in the logic to get the input data
    }
        display("BEFORE SORTING"); // display the unsorted list of audience details
        selectionSort(); // sort the list based on ticketPrice
        display("AFTER SORTING");//display the sorted list
        writeToFile();
        //write the sorted list to output file
	}  
/*Method to create Advanced Ticket object and add to audience array*/
	private static void addAdvancedTicket(String name, String ticketNumber, int days) {
		AdvancedTicket ticket = new AdvancedTicket(ticketNumber, days);
        Audience audience = new Audience(name, ticket);
        audienceList[Audience.getNoOfAudience() - 1] = audience;
	}

	/*Method to create Off campus Advanced Ticket object and add to audience array*/
	private static void addOffcampusAdvanceTicket(String name, String ticketNumber, int days, String ID) {
		OffcampusStudentAdvanceTicket ticket = new OffcampusStudentAdvanceTicket(ticketNumber, days, ID);
        Audience audience = new Audience(name, ticket);
        audienceList[Audience.getNoOfAudience() - 1] = audience;
	}

	/*Method to create On campus Advanced Ticket object and add to audience array*/
	private static void addOncampusAdvanceTicket(String name, String ticketNumber, int days, String ID) {
		OncampusStudentAdvanceTicket ticket = new OncampusStudentAdvanceTicket(ticketNumber, days, ID);
        Audience audience = new Audience(name, ticket);
        audienceList[Audience.getNoOfAudience() - 1] = audience;
	}

	/*Method to create Walkup Ticket object and add to audience array*/
	public static void addWalkupTicket(String name, String ticketNumber){
		WalkupTicket ticket = new WalkupTicket(ticketNumber);
        Audience audience = new Audience(name, ticket);
        audienceList[Audience.getNoOfAudience() - 1] = audience;
	}
	public static void display(String message) {
	    StringBuilder output = new StringBuilder();
	    for (Audience audience : audienceList) {
	        if (audience != null) {
	            output.append(audience.toString()).append("\n");
	        }
	    }
	    // Create a JTextArea to display the output
	    JTextArea textArea = new JTextArea(output.toString());
	    // Add the text area to a JScrollPane to enable scrolling
	    JScrollPane scrollPane = new JScrollPane(textArea);
	    // Show the dialog with the scrollable text area
	    JOptionPane.showMessageDialog(null, scrollPane, message, JOptionPane.INFORMATION_MESSAGE);
	}

	/*Method to sort audience object based on ticketCost using compareTo() method*/
	public static void selectionSort() {
		for (int i = 0; i < audienceList.length - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < audienceList.length; j++) {
                if (audienceList[j] != null && audienceList[j].compareTo(audienceList[minIndex]) < 0) {
                    minIndex = j;
                }
            }
            Audience temp = audienceList[minIndex];
            audienceList[minIndex] = audienceList[i];
            audienceList[i] = temp;
        }
    }

	/*Method to write audience object details into an output file*/
	public static void writeToFile() {
	    try {
	        FileWriter writer = new FileWriter("Audience.txt");
	        writer.write("Sorted Details:");
	        for (Audience audience : audienceList) {
	            if (audience != null) {
	                writer.write(audience.toString() + "\n");
	            }
	        }
	        writer.close(); // Moved outside the loop
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
}
