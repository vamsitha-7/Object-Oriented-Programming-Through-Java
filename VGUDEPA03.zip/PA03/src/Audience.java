

/*Audience class to perform manipulations on Ticket class objects*/
public class Audience implements Comparable<Audience> {

	/* Instance variable declaration*/
	private String name;
	private Ticket ticket;
	private static int noOfAudience;

	/*default constructor*/
	public Audience() {
		//Fill in
	}

	/*parameterized constructor*/
	public Audience(String name, Ticket ticket) {
		//Fill in
		this.name = name;
        this.ticket = ticket;
        noOfAudience++;
	}

	/*Getter and setter methods*/
	public String getName() {
		return name;
		//return
	}

	public void setName(String name) {
		//
		this.name = name;
	}

	public Ticket getticket() {
		//return
		return ticket;
	}

	public void setticket(Ticket ticket) {
		//
		this.ticket = ticket;
	}

	public static int getNoOfAudience() {
		//return
		return noOfAudience;
	}

	@Override //method to name and ticket object details
	public String toString() {
		//return
		return "Audience Name: " + name + ", Ticket Details: " + ticket.toString();
	}

	@Override //method to compare the ticket cost of 2 objects
	public int compareTo(Audience Audience) {
		//Fill in the logic
		double thisTicketCost = this.ticket.ticketCost;
	    double otherTicketCost = Audience.ticket.ticketCost;

	    // Compare the ticket costs
	    return Double.compare(thisTicketCost, otherTicketCost);
	}
	}
