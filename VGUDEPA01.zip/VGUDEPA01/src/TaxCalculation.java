import javax.swing.JOptionPane;
public class TaxCalculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// You have to get two input values for a person, which are income, and status.
		double incomeInDouble = 0;
        while (true) {
            try {
				// First, let us show the example of how to get the input value of the income of the person using JOptionPane
				String incomeInputValue =JOptionPane.showInputDialog("Enter income of one person. Enter value as a whole number, without any decimal, e.g., 15125");
				//for the sake of simplicity, enter the income as a whole number (not a decimal number) in the input
				// There is no need to enter a comma in the income, but enter the income as 15125, or 67897 etc.
				// The code above gets the income value of the person income in the variable income.
				// However, this data type is String. In other words, even if the value of the data is indeed of type integer, the data type is String.
				// You can to convert the String data type to into double type.
				// use the parseDouble to convert String data type to double.
				// the data type is kept as double, because to calculate the tax, you have to multiply with values as 0.1 etc.
				incomeInDouble=Double.parseDouble(incomeInputValue);  
				if (incomeInDouble < 0) {
                    throw new IllegalArgumentException("Income cannot be negative.");
				}
				break;
            }
            catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid income format. Please enter a whole number.");
            }
            catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }
        int statusInInt = 0;
        while (true)
        {
				// Next, let us show the example of how to get the status of the person.
				// The status of the person can be either Single, or Married.
				// Showing below how to get the input value of the status of the person using JOptionPane
				String statusInString =JOptionPane.showInputDialog("Enter status of person, Enter either the value of Single, or Married.");  
				// Next, you will use switch statement to convert the status to a value of either 0, or 1.
				// If the value entered in the input above input is Single, then assign a value of 0.
				// If the value entered in the input above Married, then assign a value of 1.
				// Create a new variable statusInInt to hold the status, and the data type of this new variable is int.
				 // declare a variable for that, and initialize to a value
				// The value entered has to exactly match as Single (or Married) because the switch statement below looks for those values
				try { 
                   switch (statusInString) {
                    case "Single":
                       statusInInt=0;
                       break;
                    case "Married":
                        statusInInt=1;
                        break;
                    default:
                    	throw new IllegalArgumentException("Invalid status. Please enter Single or Married.");
                };
			            	// Default section of the code is executed if the value entered does not match the above value
				break;
			        }catch(IllegalArgumentException e) {
		                JOptionPane.showMessageDialog(null, e.getMessage());
		            }
		        }
			
			// At this point, you have two variable, which are icomeInDouble and statusInInt for the person.
			// You will use these two variable for the tax calculation of the person.
			
			// Use if statement for calculating the tax.
			// Use the tax table to determine the tax of the person
			// You will write code using the if statement to decide the tax.
			double tax = 0; // initializing variable tax to a value
			if(statusInInt==0){
				// Write code to calculate the tax, based on the income, if status is Single
				if(incomeInDouble <=8350 )
				{
					tax = incomeInDouble * 0.1 ;
				}
				else if((incomeInDouble >=8351 && incomeInDouble<= 33950) )
				{
					// You will write code to calculate tax
					tax=((8350*0.1)+(incomeInDouble-8350)*0.15);
				}
				else if((incomeInDouble >=33951 && incomeInDouble<= 82250) )
				{
					// You will write code to calculate tax
					tax=((8350*0.1)+((33950-8350)*.15)+((incomeInDouble-33950)*0.25));
				}
				else if((incomeInDouble >=82251 && incomeInDouble<= 171550) )
				{
					// You will write code to calculate tax
					tax=((8350*0.1)+((33950-8350)*.15)+((82250-33950)*0.25)+((incomeInDouble-82250)*0.28));
				}
				else if((incomeInDouble >=171551 && incomeInDouble<= 372950) )
				{
					// You will write code to calculate tax
					tax=((8350*0.1)+((33950-8350)*.15)+((82250-33950)*0.25)+(171550-82250)*0.28)+((incomeInDouble-171550)*0.33);
				}
				else if((incomeInDouble >=372951) )
				{
					// You will write code to calculate tax
					tax=((8350*0.1)+((33950-8350)*.15)+((82250-33950)*0.25)+(171550-82250)*0.28)+((372950-171550)*0.33)+((incomeInDouble-372950)*0.35);
				}
				// You will write code to calculate tax based on the other income slabs
				
			}
			else if(statusInInt==1)
			{
				// Write code to calculate the tax, based on the income slab, if status is Married
				if(incomeInDouble <=16700 )
				{
					tax = incomeInDouble * 0.1 ;
				}
				else if((incomeInDouble >=16701 && incomeInDouble<= 67900) )
				{
					// You will write code to calculate tax
					tax=((16700*0.1)+(incomeInDouble-16700)*0.15);
				}
				else if((incomeInDouble >=67901 && incomeInDouble<= 137050) )
				{
					// You will write code to calculate tax
					tax=((16700*0.1)+((67900-16700)*.15)+((incomeInDouble-67901)*0.25));
				}
				else if((incomeInDouble >=137051 && incomeInDouble<= 208850) )
				{
					// You will write code to calculate tax
					tax=((16700*0.1)+((67900-16700)*.15)+((137050-67900)*0.25)+((incomeInDouble-137050)*0.28));
				}
				else if((incomeInDouble >=171551 && incomeInDouble<= 372950) )
				{
					// You will write code to calculate tax
					tax=((16700*0.1)+((67900-16700)*.15)+((137050-67900)*0.25)+(208850-137050)*0.28)+((incomeInDouble-208850)*0.33);
				}
				else if((incomeInDouble >=372951) )
				{
					// You will write code to calculate tax
					tax=((16700*0.1)+((67900-16700)*.15)+((137050-67900)*0.25)+(208850-137050)*0.28)+((372950-208851)*0.33)+((incomeInDouble-372950)*0.35);
				}
			}
			
			// Use JOptionPane to display the income, status, and the computed tax.
			// using the variable statusInString for the display purpose, instead of showing 0, or 1
			// The use of \n makes it to display each value in a new line
			String statusString = statusInInt == 0 ? "Single" : "Married";
			JOptionPane.showMessageDialog(null, "Income = "+ incomeInDouble + "\n"+
											" Status = "+ statusString  + "\n"+ 
											"Tax= " + tax);	
	}

}
