import javax.swing.JOptionPane;
import javax.swing.JTextArea;
public class VendingMachine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double balanceChange;
		String itemName = "";
        double itemPrice = 0.0;
        String optionInput="";
		try {
			 optionInput = JOptionPane.showInputDialog(null,
                    new JTextArea("1. Trail Mix \t\t $1.25\n2. Snickers \t\t $2.00\n3. Chewing gum \t $0.50\n4. Cheetos \t\t $5.75"),"MY VENDING MACHINE OPTIONS",JOptionPane.INFORMATION_MESSAGE);
            switch (optionInput) {
                case "1":
                    itemName = "Trail Mix";
                    itemPrice = 1.25;
                    break;
                case "2":
                    itemName = "Snickers";
                    itemPrice = 2.00;
                    break;
                case "3":
                    itemName = "Chewing gum";
                    itemPrice = 0.50;
                    break;
                case "4":
                	itemName = "Cheetos";
                	itemPrice = 5.75;
                	break;
                default:
                    throw new IllegalArgumentException("You Entered: "+ optionInput + " \nNot a valid option! System Abort");
            }
            String bill = JOptionPane.showInputDialog(null,new JTextArea("Please Insert Money for: " + itemName + "\nExpected money is: " + itemPrice + "\nYou may insert only : $1, $5 and $10 bills \nWe accept only one of these 3 bills\nCards and changes are not accepted"));
            int billNote = Integer.parseInt(bill);
            if (billNote != 1 && billNote != 5 && billNote != 10) {
                throw new IllegalArgumentException("Your bill: "+ billNote + "\nNot a valid bill! System Abort");
            }
            if (billNote < itemPrice) {
                throw new IllegalArgumentException("Your bill: "+ billNote + "\nNot a valid bill! System Abort");
            }
            double balancePrice = billNote - itemPrice;
            int fiveDollar, oneDollar, fiftyCent, twentyFiveCent;
         if (balancePrice >= 5) {
             fiveDollar = (int) (balancePrice / 5);
             balanceChange = balancePrice % 5;
         } else {
             fiveDollar = 0;
             balanceChange  = balancePrice;
         }
         if (balanceChange  >= 1) {
             oneDollar = (int) (balanceChange  / 1);
             balanceChange  %= 1;
         } else {
             oneDollar = 0;
         }
         if (balanceChange  >= 0.50) {
             fiftyCent = (int) (balanceChange  / 0.50);
             balanceChange  %= 0.50;
         } else {
             fiftyCent = 0;
         }
         if (balanceChange  >= 0.25) {
             twentyFiveCent = (int) (balanceChange / 0.25);
         } else {
             twentyFiveCent = 0;
         }
            String output = "Your selected item number " + optionInput +" which is " + itemName + "\n\nCost of "+ itemName +" is\t$"+ itemPrice + "\nYou Inserted\t\t$" + billNote + "\nYour balance is\t\t$"+ (billNote - itemPrice)+ "\n\nThe Change you get is:\n\t" + fiveDollar+" * $5\n\t"+oneDollar+" * $1\n\t"+fiftyCent+" * $0.50\n\t"+twentyFiveCent+" * $0.25\n\t";
            JOptionPane.showMessageDialog(null,new JTextArea(output),"TRANSACTION SUMMARY", JOptionPane.INFORMATION_MESSAGE);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid bill. Please provide valid bill");
        } catch (IllegalArgumentException e) {
        	 JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "An error occurred. Exiting the program.");
        }

	}

}