

// add the class to package PP04
// add the class template

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.*;
import java.net.*;
import java.sql.*;
import javax.swing.*;

class PetClent extends JFrame implements ActionListener{


	private String hostname="BUSCISMYSQL01";
	private int port=3306;
	private Message msg;
	private Socket socket;
	private ObjectOutputStream toServer;
	private ObjectInputStream fromServer;

// declare UI component objects
	private JTextField tagField, petNameField, ownerSSNField, firstNameField, lastNameField;
    private JComboBox<String> speciesDropdown;
    private JButton insertButton, viewButton, updateButton, deleteButton, clearButton, closeButton;
    
    public PetClent(String hostname, int port) {
    super("Pet and Owner Application");
	this.port = port;
	this.hostname = hostname;

	// Create a connection with the PetServer server on port number 8000
	 try {
         // Attempt to establish a connection to the server
         socket = new Socket(hostname, port);  // Connect to the specified host and port
         toServer = new ObjectOutputStream(socket.getOutputStream());  // For sending messages to the server
         fromServer = new ObjectInputStream(socket.getInputStream());  
         System.out.println("Connected to server at " + hostname + ":" + port);// For receiving messages from the server
     } catch (IOException e) {
         JOptionPane.showMessageDialog(this, "Error connecting to server: " + e.getMessage(),
                 "Connection Error", JOptionPane.ERROR_MESSAGE);
             e.printStackTrace();  // Print the stack trace for debugging
         } // Stop further execution if connection fails
	// call these two methods to create user GUI
	initComponenet();
	doTheLayout();
	addEventHandlers();
	setupFrame();
	 connectToServer();
}
    private void connectToServer() {
        try {
            // Connect to the server
            socket = new Socket(hostname, port);
            // Create an output stream to send data to the server
            toServer = new ObjectOutputStream(socket.getOutputStream());
            // Create an input stream to receive data from the server
            fromServer = new ObjectInputStream(socket.getInputStream());
        }  catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Failed to connect to the server: " + ex.getMessage(), "Connection Error", JOptionPane.ERROR_MESSAGE);
            toServer = null;  // Ensure the stream is null if connection failed
        }
    }
    private void initComponenet() {
    	// Initialize the GUI components
    	tagField = new JTextField(10);
        petNameField = new JTextField(10);
        ownerSSNField = new JTextField(10);
        firstNameField = new JTextField(10);
        lastNameField = new JTextField(10);
        speciesDropdown = new JComboBox<>(new String[]{"Dog", "Cat"});
        
        insertButton = new JButton("Insert");
        viewButton = new JButton("View");
        updateButton = new JButton("Update");
        deleteButton = new JButton("Delete");
        clearButton = new JButton("Clear");
        closeButton = new JButton("Close");

    }

    private void doTheLayout() {
    	// Arrange the UI components into GUI window
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0; gbc.gridy = 0;
        add(new JLabel("Tag"), gbc);

        gbc.gridx = 1; gbc.gridy = 0;
        add(tagField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        add(new JLabel("Pet Name"), gbc);

        gbc.gridx = 1; gbc.gridy = 1;
        add(petNameField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        add(new JLabel("Owner SSN"), gbc);

        gbc.gridx = 1; gbc.gridy = 2;
        add(ownerSSNField, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        add(new JLabel("First Name"), gbc);

        gbc.gridx = 1; gbc.gridy = 3;
        add(firstNameField, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        add(new JLabel("Last Name"), gbc);

        gbc.gridx = 1; gbc.gridy = 4;
        add(lastNameField, gbc);

        gbc.gridx = 0; gbc.gridy = 5;
        add(new JLabel("Species"), gbc);

        gbc.gridx = 1; gbc.gridy = 5;
        add(speciesDropdown, gbc);

        gbc.gridwidth = 2;
        gbc.gridx = 0; gbc.gridy = 6;
        add(insertButton, gbc);

        gbc.gridwidth = 1; // reset to default
        gbc.gridx = 2; gbc.gridy = 0;
        add(viewButton, gbc);

        gbc.gridx = 2; gbc.gridy = 1;
        add(updateButton, gbc);

        gbc.gridx = 2; gbc.gridy = 2;
        add(deleteButton, gbc);

        gbc.gridx = 2; gbc.gridy = 3;
        add(clearButton, gbc);

        gbc.gridx = 2; gbc.gridy = 4;
        add(closeButton, gbc);
    }

@Override
public void actionPerformed(ActionEvent e) {
	try {
        if (e.getSource() == insertButton) {
            insertButtonClicked();
        } else if (e.getSource() == viewButton) {
            viewButtonClicked();
        } else if (e.getSource() == updateButton) {
            updateButtonClicked();
        } else if (e.getSource() == deleteButton) {
            deleteButtonClicked();
        } else if (e.getSource() == clearButton) {
            clearButtonClicked();
        } else if (e.getSource() == closeButton) {
            closeButtonClicked();
        }
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
	
}
private void addEventHandlers() {
    insertButton.addActionListener(this);
    viewButton.addActionListener(this);
    updateButton.addActionListener(this);
    deleteButton.addActionListener(this);
    clearButton.addActionListener(this);
    closeButton.addActionListener(this);
}

private void setupFrame() {
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(700, 700);
    setLocationRelativeTo(null);
    setVisible(true);
}
private void viewButtonClicked() {
	// handle view button clicked event
    if (toServer == null) {
        JOptionPane.showMessageDialog(this, "Not connected to the server.", "Connection Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    try {
        String tag = tagField.getText().trim();

        if (tag.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tag cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int tagNum = Integer.parseInt(tag);

        // Create a message object for the view operation
        Message message = new Message(tagNum, 0, 2, null, null, null, null);

        // Send the message object to the server
        toServer.writeObject(message);

        // Read the response from the server
        Object response = fromServer.readObject();

        if (response instanceof String && ((String) response).startsWith("No record found")) {
            JOptionPane.showMessageDialog(this, (String) response, "View Result", JOptionPane.INFORMATION_MESSAGE);
        } else if (response instanceof String) {
            String[] data = ((String) response).split(", ");
            petNameField.setText(data[0].split(": ")[1]);
            speciesDropdown.setSelectedItem(data[1].split(": ")[1]);
            ownerSSNField.setText(data[2].split(": ")[1]);
            firstNameField.setText(data[3].split(": ")[1]);
            lastNameField.setText(data[4].split(": ")[1]);
        }
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Please enter a valid number for Tag.", "Input Error", JOptionPane.ERROR_MESSAGE);
    } catch (IOException ex) {
        JOptionPane.showMessageDialog(this, "Communication Error: " + ex.getMessage(), "Connection Error", JOptionPane.ERROR_MESSAGE);
    } catch (ClassNotFoundException ex) {
        JOptionPane.showMessageDialog(this, "Error processing the response from the server.", "Error", JOptionPane.ERROR_MESSAGE);
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Unexpected error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

	private void insertButtonClicked() {
		// handle insert button clicked event 
	    // Check if the client is connected to the server
	    if (toServer == null) {
	        JOptionPane.showMessageDialog(this, "Not connected to the server.", "Connection Error", JOptionPane.ERROR_MESSAGE);
	        return;  // Exit the method if not connected
	    }

	    try {
	        String tag = tagField.getText().trim();
	        String petName = petNameField.getText().trim();
	        String ownerSSN = ownerSSNField.getText().trim();
	        String firstName = firstNameField.getText().trim();
	        String lastName = lastNameField.getText().trim();
	        String species = (String) speciesDropdown.getSelectedItem();

	        if (tag.isEmpty() || petName.isEmpty() || ownerSSN.isEmpty() || firstName.isEmpty() || lastName.isEmpty()) {
	            JOptionPane.showMessageDialog(this, "All fields must be filled.", "Error", JOptionPane.ERROR_MESSAGE);
	            return;
	        }

	        int tagNum = Integer.parseInt(tag);
	        int ssnNum = Integer.parseInt(ownerSSN);

	        // Create a message object to send to the server
	        Message message = new Message(tagNum, ssnNum, 1, petName, species, firstName, lastName);
	        
	        // Send the message object to the server
	        toServer.writeObject(message);

	        // Read the response from the server
	        String response = (String) fromServer.readObject();
	        JOptionPane.showMessageDialog(this, response, "Server Response", JOptionPane.INFORMATION_MESSAGE);
	        clearButtonClicked();  
	    } catch (NumberFormatException ex) {
	        JOptionPane.showMessageDialog(this, "Please enter valid numbers for Tag and SSN.", "Input Error", JOptionPane.ERROR_MESSAGE);
	    } catch (IOException ex) {
	        JOptionPane.showMessageDialog(this, "Communication Error: " + ex.getMessage(), "Connection Error", JOptionPane.ERROR_MESSAGE);
	    } catch (ClassNotFoundException ex) {
	        JOptionPane.showMessageDialog(this, "Error processing the response from the server.", "Error", JOptionPane.ERROR_MESSAGE);
	    } catch (Exception ex) {
	        JOptionPane.showMessageDialog(this, "Unexpected error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}




	private void updateButtonClicked() {
		// handle update button clicked event
	    if (toServer == null) {
	        JOptionPane.showMessageDialog(this, "Not connected to the server.", "Connection Error", JOptionPane.ERROR_MESSAGE);
	        return;
	    }

	    try {
	        String tag = tagField.getText().trim();
	        String newPetName = petNameField.getText().trim();

	        if (tag.isEmpty() || newPetName.isEmpty()) {
	            JOptionPane.showMessageDialog(this, "Tag and Pet Name cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
	            return;
	        }

	        int tagNum = Integer.parseInt(tag);

	        // Create a message object for the update operation
	        Message message = new Message(tagNum, 0, 3, newPetName, null, null, null);

	        // Send the message object to the server
	        toServer.writeObject(message);

	        // Read the response from the server
	        String response = (String) fromServer.readObject();
	        JOptionPane.showMessageDialog(this, response, "Server Response", JOptionPane.INFORMATION_MESSAGE);
	    } catch (NumberFormatException ex) {
	        JOptionPane.showMessageDialog(this, "Please enter a valid number for Tag.", "Input Error", JOptionPane.ERROR_MESSAGE);
	    } catch (IOException ex) {
	        JOptionPane.showMessageDialog(this, "Communication Error: " + ex.getMessage(), "Connection Error", JOptionPane.ERROR_MESSAGE);
	    } catch (ClassNotFoundException ex) {
	        JOptionPane.showMessageDialog(this, "Error processing the response from the server.", "Error", JOptionPane.ERROR_MESSAGE);
	    } catch (Exception ex) {
	        JOptionPane.showMessageDialog(this, "Unexpected error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}

	// handle delete button clicked event
	private void deleteButtonClicked(){
		// handle delete button clicked event
	    if (toServer == null) {
	        JOptionPane.showMessageDialog(this, "Not connected to the server.", "Connection Error", JOptionPane.ERROR_MESSAGE);
	        return;
	    }

	    try {
	        String tag = tagField.getText().trim();
	        if (tag.isEmpty()) {
	            JOptionPane.showMessageDialog(this, "Tag cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
	            return;
	        }

	        int tagNum = Integer.parseInt(tag);
	        Message message = new Message(tagNum, 0, 4, "", "", "", "");  // OpType 4 for delete
	        toServer.writeObject(message);

	        String response = (String) fromServer.readObject();
	        JOptionPane.showMessageDialog(this, response, "Server Response", JOptionPane.INFORMATION_MESSAGE);

	        clearButtonClicked(); 
	    } catch (NumberFormatException ex) {
	        JOptionPane.showMessageDialog(this, "Tag must be a number.", "Input Error", JOptionPane.ERROR_MESSAGE);
	    } catch (IOException ex) {
	        JOptionPane.showMessageDialog(this, "Communication Error: " + ex.getMessage(), "Connection Error", JOptionPane.ERROR_MESSAGE);
	    } catch (ClassNotFoundException ex) {
	        JOptionPane.showMessageDialog(this, "Error processing the response from the server.", "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
  
private void clearButtonClicked(){
	  
	// handle clear button clicked event
	tagField.setText("");
    petNameField.setText("");
    ownerSSNField.setText("");
    firstNameField.setText("");
    lastNameField.setText("");
    speciesDropdown.setSelectedIndex(0);
  }
  

private  void closeButtonClicked(){
	  
	// handle close button clicked event
	System.exit(0);
  }
  
  /**Main method*/
  public static void main(String[] args) {
	  SwingUtilities.invokeLater(() -> {
	        try {
	            PetClent client = new PetClent("localhost", 3306);
	            client.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	            client.setSize(700, 400);
	            client.setVisible(true);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    });
	  // create the user GUI
  }// end method main()

}// end class