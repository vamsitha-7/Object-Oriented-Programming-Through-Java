import java.io.*;
import java.net.*;
import java.sql.*;
//add the class to package PP04
//add the class template 
public class PetServer {

    private ServerSocket serverSocket;
    private Connection connection;
    private int port;

    public PetServer(int port) {
        this.port = port;
        try {
            initializeDB();
            serverSocket = new ServerSocket(port);
            System.out.println("Server started on port " + port);
            while (true) {
                Socket socket = serverSocket.accept();
                new Thread(new HandleAClient(socket)).start();
            }
        }catch (IOException e) {
            System.out.println("Could not listen on port " + port);
            e.printStackTrace();
        }
    }

    private void initializeDB() {
    	// create the server
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver Loaded");
         // Connect to your database using your credentials
         // Create a statement object
         // loops for ever waiting for the client connection requests
            connection = DriverManager.getConnection(
                "jdbc:mysql://BUSCISMYSQL01/team14DB", "vamsitha", "c611c!95880");
            System.out.println("Database connected successfully.");
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error connecting to the database: " + e.getMessage());
        }
    }
    // create a thread for each client connection request using Runnable class HandleAClient
 // inner Runnable class handle a client connection
    class HandleAClient implements Runnable {
        private Socket socket; // A connected socket
        private ObjectInputStream inputFromClient;
        private ObjectOutputStream outputToClient;
        /** Construct a thread */
        public HandleAClient(Socket socket) {
            this.socket = socket;
            try {
                inputFromClient = new ObjectInputStream(socket.getInputStream());
                outputToClient = new ObjectOutputStream(socket.getOutputStream());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        /** Run a thread */
        public void run() {
        	// write the code to call a proper method to process the client request
            try {
                while (true) {
                    Message message = (Message) inputFromClient.readObject();
                    switch (message.getOpType()) {
                        case 1:
                            insert(message);
                            break;
                        case 2:
                            view(message);
                            break;
                        case 3:
                            update(message);
                            break;
                        case 4:
                            delete(message);
                            break;
                    }
                }
            } catch (Exception e) {
                System.out.println("Error handling client request: " + e.getMessage());
            }
        }// end of class Runnable 
        /**View record by ID*/
        private void view(Message message) throws SQLException, IOException {
        	// Build a SQL SELECT statement
            String sql = "SELECT pet.petName, pet.species, owner.ssn AS ownerSSN, owner.firstName, owner.lastName FROM pet JOIN owner ON pet.ownerSSN = owner.ssn WHERE pet.tag = ?";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setInt(1, message.getTag());
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    String details = "Pet Name: " + rs.getString("petName") +
                                     ", Species: " + rs.getString("species") +
                                     ", Owner SSN: " + rs.getInt("ownerSSN") +
                                     ", First Name: " + rs.getString("firstName") +
                                     ", Last Name: " + rs.getString("lastName");
                    outputToClient.writeObject(details);
                } else {
                    outputToClient.writeObject("No record found for tag: " + message.getTag());
                }
            }
        }

        /**Insert a new record*/
        private void insert(Message message) throws SQLException, IOException {
        	// Build a SQL INSERT statement
            String checkTag = "SELECT COUNT(*) FROM pet WHERE tag = ?";
            try (PreparedStatement checkStmt = connection.prepareStatement(checkTag)) {
                checkStmt.setInt(1, message.getTag());
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    outputToClient.writeObject("Tag already exists in the database");
                    return;
                }
            }

            String checkSSN = "SELECT COUNT(*) FROM owner WHERE ssn = ?";
            try (PreparedStatement checkSsnStmt = connection.prepareStatement(checkSSN)) {
                checkSsnStmt.setInt(1, message.getOwnerSSN());
                ResultSet rs = checkSsnStmt.executeQuery();
                if (!(rs.next() && rs.getInt(1) > 0)) {
                    String insertOwner = "INSERT INTO owner (ssn, firstName, lastName) VALUES (?, ?, ?)";
                    try (PreparedStatement insertOwnerStmt = connection.prepareStatement(insertOwner)) {
                        insertOwnerStmt.setInt(1, message.getOwnerSSN());
                        insertOwnerStmt.setString(2, message.getFirstName());
                        insertOwnerStmt.setString(3, message.getLastName());
                        insertOwnerStmt.executeUpdate();
                    }
                }
            }

            String insertPet = "INSERT INTO pet (tag, petName, species, ownerSSN) VALUES (?, ?, ?, ?)";
            try (PreparedStatement insertPetStmt = connection.prepareStatement(insertPet)) {
                insertPetStmt.setInt(1, message.getTag());
                insertPetStmt.setString(2, message.getPetName());
                insertPetStmt.setString(3, message.getSpecies());
                insertPetStmt.setInt(4, message.getOwnerSSN());
                int result = insertPetStmt.executeUpdate();
                if (result > 0) {
                    outputToClient.writeObject("Record inserted successfully.");
                } else {
                    outputToClient.writeObject("Failed to insert record.");
                }
                
            }
        }
        /**Update a record*/
        private void update(Message message) throws SQLException, IOException {
        	// Build a SQL UPDATE statement
            String sql = "UPDATE pet SET petName = ? WHERE tag = ?";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, message.getPetName());
                stmt.setInt(2, message.getTag());
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    outputToClient.writeObject("Update successful: Pet name updated.");
                } else {
                    outputToClient.writeObject("No record found to update with tag: " + message.getTag());
                }
            }
        }

        /**Clear text fields*/
        private void delete(Message message) throws SQLException, IOException {
        	// Build a SQL DELETE statement
            String sql = "SELECT * FROM pet WHERE tag = ?";
            try (PreparedStatement checkStmt = connection.prepareStatement(sql)) {
                checkStmt.setInt(1, message.getTag());
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next()) {
                    String deleteSql = "DELETE FROM pet WHERE tag = ?";
                    try (PreparedStatement deleteStmt = connection.prepareStatement(deleteSql)) {
                        deleteStmt.setInt(1, message.getTag());
                        int rowsAffected = deleteStmt.executeUpdate();
                        if (rowsAffected > 0) {
                            outputToClient.writeObject("Record deleted successfully.");
                        } else {
                            outputToClient.writeObject("Failed to delete the record.");
                        }
                    }
                } else {
                    outputToClient.writeObject("Tag value does not exist in the database.");
                }
            }
        }
    }

    public static void main(String[] args) {
    	new PetServer(3306);
    }
}// end class
