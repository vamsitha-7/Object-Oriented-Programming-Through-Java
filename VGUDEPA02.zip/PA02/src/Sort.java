import javax.swing.JOptionPane;

public class Sort {

    public static void selectionSort(String[] pName, double[] pPrice) {
        for (int i = 0; i < pPrice.length - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < pPrice.length; j++) {
                if (pPrice[j] < pPrice[minIndex]) {
                    minIndex = j;
                }
            }
            swap(pName, pPrice, i, minIndex);
        }
        JOptionPane.showMessageDialog(null, "Completed Sorting Arrays");
    }

    private static void swap(String[] pName, double[] pPrice, int i, int j) {
        if (i != j) {
            double tempPrice = pPrice[j];
            pPrice[j] = pPrice[i];
            pPrice[i] = tempPrice;
            String tempName = pName[j];
            pName[j] = pName[i];
            pName[i] = tempName;
        }
    }
}