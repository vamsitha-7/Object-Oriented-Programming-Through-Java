import javax.swing.JOptionPane;

public class CostAnalysis {
    public static void main(String[] args) {
        double[] product1Costs = new double[4];
        double[] product2Costs = new double[4];
        inputExpenditures("Product 1", product1Costs);
        inputExpenditures("Product 2", product2Costs);
        displayResults(product1Costs, product2Costs);
    }
    public static void inputExpenditures(String productName, double[] costs) {
        JOptionPane.showMessageDialog(null, "Enter marketing costs for " + productName);
        String[] expenditureItems = {
                "Website marketing & Search engine marketing",
                "Social media marketing",
                "Radio advertising",
                "Newspaper advertising"
        };
        for (int i = 0; i < costs.length; i++) {
            String input = JOptionPane.showInputDialog("Enter cost for " + expenditureItems[i] + " for " + productName);
            try {
                costs[i] = Double.parseDouble(input);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.");
                i--; 
            }
        }
    }
    public static double totalCostPerProduct(double[] costs) {
        double total = 0;
        for (double cost : costs) {
            total += cost;
        }
        return total;
    }
    public static double totalCostPerExpenditure(double[] product1Costs, double[] product2Costs, int index) {
        return product1Costs[index] + product2Costs[index];
    }
    public static double highestCostCalculator(double[] costs) {
        double highest = costs[0];
        for (double cost : costs) {
            if (cost > highest) {
                highest = cost;
            }
        }
        return highest;
    }
    public static double lowestCostCalculator(double[] costs) {
        double lowest = costs[0];
        for (double cost : costs) {
            if (cost < lowest) {
                lowest = cost;
            }
        }
        return lowest;
    }
    public static double percentageCalculator(double total, double expenditure) {
        return (expenditure / total) * 100;
    }
    public static void displayResults(double[] product1Costs, double[] product2Costs) {
        
        // Display the results
        String result = "Expenditure Item\t\tProduct-1\tProduct-2\tTotal Cost\n";
        result += "Radio advertising\t$" + product1Costs[0] + "\t$" + product2Costs[0] + "\t$" + totalCostPerExpenditure(product1Costs, product2Costs, 0)
                + " (" + String.format("%.2f", percentageCalculator(totalCostPerProduct(product1Costs) + totalCostPerProduct(product2Costs), totalCostPerExpenditure(product1Costs, product2Costs, 0))) + "%)\n";
        result += "Social media marketing\t$" + product1Costs[1] + "\t$" + product2Costs[1] + "\t$" + totalCostPerExpenditure(product1Costs, product2Costs, 1)
                + " (" + String.format("%.2f", percentageCalculator(totalCostPerProduct(product1Costs) + totalCostPerProduct(product2Costs), totalCostPerExpenditure(product1Costs, product2Costs, 1))) + "%)\n";
        result += "Radio advertising\t$" + product1Costs[2] + "\t$" + product2Costs[2] + "\t$" + totalCostPerExpenditure(product1Costs, product2Costs, 2)
                + " (" + String.format("%.2f", percentageCalculator(totalCostPerProduct(product1Costs) + totalCostPerProduct(product2Costs), totalCostPerExpenditure(product1Costs, product2Costs, 2))) + "%)\n";
        result += "Newspaper advertising\t$" + product1Costs[3] + "\t$" + product2Costs[3] + "\t$" + totalCostPerExpenditure(product1Costs, product2Costs, 3)
                + " (" + String.format("%.2f", percentageCalculator(totalCostPerProduct(product1Costs) + totalCostPerProduct(product2Costs), totalCostPerExpenditure(product1Costs, product2Costs, 3))) + "%)\n";
        result += "Total cost per product\t$" + totalCostPerProduct(product1Costs) + "\t$" + totalCostPerProduct(product2Costs) + "\t$" + (totalCostPerProduct(product1Costs) + totalCostPerProduct(product2Costs)) + "\n";
        result += "Highest Expenditure\t" + "Radio advertising\t" + "Radio advertising\t" + "Radio advertising\n";
        result += "Lowest Expenditure\t" + "Newspaper advertising\t" + "Newspaper advertising\t" + "Newspaper advertising\n";
        result += "Highest Expenditure on both products\t$" + Math.max(highestCostCalculator(product1Costs), highestCostCalculator(product2Costs)) + "\n";
        result += "Lowest Expenditure on both products\t$" + Math.min(lowestCostCalculator(product1Costs), lowestCostCalculator(product2Costs)) + "\n";

        JOptionPane.showMessageDialog(null, result);
    }
}