import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Product {

    public static void main(String[] args) {
        String fileName = JOptionPane.showInputDialog("Input the file name of the input file:");
        String[] pName = new String[50];
        double[] pPrice = new double[50];
        readFromFile(fileName, pName, pPrice);
        displayData("Before Sorting", pName, pPrice);
        Sort.selectionSort(pName, pPrice);
        displayData("After Sorting", pName, pPrice);
        writeToFile("sortedProducts.txt", pName, pPrice);
    }
    public static void readFromFile(String fileName, String[] pName, double[] pPrice) {
        try {
            Scanner sc = new Scanner(new File(fileName));
            int i = 0;
            while (sc.hasNext() && i < 50) {
                String line = sc.nextLine();
                String[] parts = line.split(",");
                pName[i] = parts[0].trim();
                pPrice[i] = Double.parseDouble(parts[1].trim());
                i++;
            }
            sc.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading from file: " + e.getMessage());
            System.exit(1);
        }
    }

    public static void writeToFile(String fileName, String[] pName, double[] pPrice) {
        try {
            PrintWriter writer = new PrintWriter(new File(fileName));
            for (int i = 0; i < pName.length && pName[i] != null; i++) {
                writer.println(pName[i] + "," + pPrice[i]);
            }
            writer.close();
            JOptionPane.showMessageDialog(null, "Sorted data has been written to file: " + fileName);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing to file: " + e.getMessage());
            System.exit(1);
        }
    }

    public static void displayData(String message, String[] pName, double[] pPrice) {
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.append(message + ":\n");
        for (int i = 0; i < pName.length && pName[i] != null; i++) {
            textArea.append(pName[i] + "\t\t$" + String.format("%.2f", pPrice[i]) + "\n");
        }
        JScrollPane scrollPane = new JScrollPane(textArea);
        JOptionPane.showMessageDialog(null, scrollPane, "Products and Prices", JOptionPane.INFORMATION_MESSAGE);
     
    }
}
