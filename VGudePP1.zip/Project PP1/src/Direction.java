// This class must have the code in the run() method to solve the maze
// It searches for the Java logo based on the provided path/direction algorithm in Part II

public class Direction extends Thread{

	Maze maze;
	Position location;
	
	Direction(Maze maze, Position location) {
		
		this.maze = maze;
		this.location = location;
	}
		public void run()
		{
			int currRow = maze.getCurrRow();
       	 int currCol = maze.getCurrCol();
       	 int row=maze.getHeight();
       	 int col=maze.getWidth();
       	  while (!maze.isDone() && !((currRow == 0 || currRow == row - 1) && currCol == col - 1)) {
       	        boolean success = false;

       	        // step-1:Check if current column is even or odd for movement direction
       	        // step-2: if even go to step-3 which is the below if loop
       	        // if odd go to step-4 which is the else loop
       	        if (currCol % 2 == 0)
       	        { 
       	        	// step-3: Even column, move down, if can't move down or have an obstacle go to step-5
       	            if (currRow < row - 1)
       	            {
       	            	success = maze.moveDown();
       	            	location.textArea.append("Success - Moved down\n");
       	                if (maze.isDone())//keep checking if maze is done for every step
       	                {
               	        	location.textArea.append("Logo Found \n");
               	            break;
               	        }
       	                if (!success)
       	                { 
       	                	location.textArea.append("Failure - Unable to move down\n");
       	                	//step-5: when encountered an obstacle try moving right, down, down, left
       	                    if (maze.moveRight())
       	                    { 
       	                    	location.textArea.append("Success - Moved right\n");
       	                    	currRow = maze.getCurrRow();
       	                    	currCol = maze.getCurrCol();
       	            	        location.textArea.append("Moved to row " + currRow + ", column " + currCol + "\n");
       	                    	if (maze.isDone())
       	                    	{
       	            	        	location.textArea.append("Logo Found \n");
       	            	            break;
       	            	        }
       	                        if (maze.moveDown())
       	                        {  
       	                        	location.textArea.append("Success - Moved down\n");
       	                        	currRow = maze.getCurrRow();
       	                        	currCol= maze.getCurrCol();
           	            	        location.textArea.append("Moved to row " + currRow + ", column " + currCol + "\n");
       	                        	if (maze.isDone())
       	                        	{
       	                	        	location.textArea.append("Logo Found \n");
       	                	            break;
       	                	        }
       	                            maze.moveDown();
       	                         location.textArea.append("Success - Moved down\n");
       	                         currRow = maze.getCurrRow();
       	                         currCol = maze.getCurrCol();
           	            	        location.textArea.append("Moved to row " + currRow + ", column " + currCol+ "\n");
       	                            if (maze.isDone())
       	                            {
       	                	        	location.textArea.append("Logo Found \n");
       	                	            break;
       	                	        }
       	                            maze.moveLeft();
       	                         location.textArea.append("Success - Moved left\n");
       	                         currRow = maze.getCurrRow();
       	                         currCol = maze.getCurrCol();
           	            	        location.textArea.append("Moved to row " + currRow + ", column " +currCol+ "\n");
       	                            if (maze.isDone())
       	                            {
       	                	        	location.textArea.append("Logo Found \n");
       	                	            break;
       	                	        }
       	                        }
       	                    }
       	                }
       	            }
       	        }//close the even col if loop
       	        //step-4: Even column, move down, if can't move down or have an obstacle go to step-6
       	        else
       	        { 
       	            if (currRow > 0)
       	            {
       	            	success = maze.moveUp();
       	            	location.textArea.append("Success - Moved up\n");
       	                if (maze.isDone())
       	                {
               	        	location.textArea.append("Logo Found \n");
               	            break;
               	        }
       	                if (!success)
       	                { 
       	                	location.textArea.append("Failure - Unable to move up\n");
       	               //step-6: when encountered an obstacle try moving left, up, up, right
       	                    if (maze.moveLeft())
       	                    {
       	                    	location.textArea.append("Success - Moved left\n");
       	                    	currRow = maze.getCurrRow();
       	                    	currCol = maze.getCurrCol();
       	            	        location.textArea.append("Moved to row " + currRow + ", column " +currCol + "\n");
       	                    	if (maze.isDone())
       	                    	{
       	            	        	location.textArea.append("Logo Found \n");
       	            	            break;
       	            	        }
       	                        if (maze.moveUp())
       	                        {
       	                        	location.textArea.append("Success - Moved up\n");
       	                        	currRow = maze.getCurrRow();
       	                        	currCol = maze.getCurrCol();
           	            	        location.textArea.append("Moved to row " + currRow + ", column " +currCol+ "\n");
       	                        	if (maze.isDone())
       	                        	{
       	                	        	location.textArea.append("Logo Found \n");
       	                	            break;
       	                	        }
       	                            maze.moveUp();
       	                         location.textArea.append("Success - Moved up\n");
       	                         currRow= maze.getCurrRow();
       	                         currCol = maze.getCurrCol();
           	            	        location.textArea.append("Moved to row " + currRow + ", column " + currCol+ "\n");
       	                            if (maze.isDone())
       	                            {
       	                	        	location.textArea.append("Logo Found \n");
       	                	            break;
       	                	        }
       	                            maze.moveRight();
       	                         location.textArea.append("Success - Moved right\n");
       	                         currRow = maze.getCurrRow();
       	                          currCol = maze.getCurrCol();
           	            	        location.textArea.append("Moved to row " + currRow+ ", column " + currCol+ "\n");
       	                            if (maze.isDone()) {
       	                	        	location.textArea.append("Logo Found \n");
       	                	            break;
       	                	        }
       	                        }
       	                    }
       	                }
       	            }
       	        }

       	        // updating the row and column 
       	     currRow = maze.getCurrRow();
       	     currCol = maze.getCurrCol();

       	        // Display current position
       	        location.textArea.append("Moved to row " + currRow + ", column " + currCol + "\n");

       	        // Check if the Java logo is found
       	        if (maze.isDone())
       	        
       	        {
       	        	location.textArea.append("Java Logo is found!");
       	            break;
       	        }
                // resetting to last column or move right at the edge 
       	        if ((currCol % 2 == 0 && currRow == row - 1) || (currCol % 2 != 0 && currRow == 0))
       	        {
       	            if (currCol < maze.getWidth() - 1)
       	            {
       	                maze.moveRight();
       	             location.textArea.append("Success - Moved right\n");
       	            } 
       	            else if (currRow == 0 && currCol == col - 1)
       	            { 
       	                break; 
       	            }
       	        }
       	    }
       	    
     // checking if we found the logo at the end or not
       	  if (!maze.isDone())
       	  {
     	        System.out.println("Reached the end of the maze without finding the Java logo.");
     	    }
		}
}
	// This is the code part that needs to be programmed by students to solve the maze 
	// using the provided path/direction algorithm
	// Get height (rows) of maze 
	// Get height (rows) of maze 
	
// This is a SAMPLE code for moving the student image in the maze
	// and updates the information in Position.java GUI class, append text into the JTextArea object
	// you should delete/update this code and start your solution, you may just keep the part of updating the information
	// in the Position.java class, appending information into the JTextArea object
		
        	//while (!maze.isDone()) 
        	//{
        	   // if (!maze.moveRight()) 
        	    //{
        	        // If moving right fails, try moving down
        	        //if (!maze.moveDown()) 
        	        //{
        	            // If moving down also fails, report failure
        	            //location.textArea.append("Failure - Unable to move right or down\n");
        	            //break; // Exit the loop since no valid moves are possible
        	        //}
        	        //else 
        	        //{
        	        // Report success if moveDown() returns true
        	        //location.textArea.append("Success - Moved down\n");
        	        //location.textArea.append("Moved to row " + maze.getCurrRow() + ", column " + maze.getCurrCol() + "\n");
        	       // }
        	    //}
        	    //else 
        	    //{
        	        // If moving right is successful, report success and show current position
        	        //location.textArea.append("Success - Moved right\n");
        	        //location.textArea.append("Moved to row " + maze.getCurrRow() + ", column " + maze.getCurrCol() + "\n");
        	    //}
        	//}
        	// Report when the logo is found
        	//location.textArea.append("Logo Found \n");
        //}
//}
      