
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JOptionPane;
public class Payment {

	public static Validation validating;
	public static HashCode hashing;
	public static Customer[] customers;

	// this will check whether a card is valid
	public static Boolean isValidCard(String number){
		 try {
	            return validating.aValidNumber(number);
	        } catch (NumberFormatException e) {
	            JOptionPane.showMessageDialog(null, "Invalid input format for credit card number.");
	            return false;
	        }
	    }
	// end of the isValidCard method

	// creates a hash code for the credit card number to be stored in file
    public static String createHashCode(String number){
    	return hashing.getHashCode(number);

	}// end of the createHashCode method


     // it adds a new customer to the array of customers once the payment was successful
 	 public static void addCustomer(Customer customer){
 		for (int i = 0; i < customers.length; i++) {
            if (customers[i] == null) {
                customers[i] = customer;
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Maximum number of customers reached.");
    }// end of the addCustomer method


	// it displays the payments AVG, MAX payment, and MIN payment,
	// only for accepted payments with valid cards
	public static void displayStat(){
		double totalPayment = 0;
        double maxPayment = Double.MIN_VALUE;
        double minPayment = Double.MAX_VALUE;
        int validCustomersCount = 0;

        for (Customer customer : customers) {
            if (customer != null && isValidCard(Long.toString(customer.getCard().getNumber()))) {
                totalPayment += customer.getAmount();
                if (customer.getAmount() > maxPayment) {
                    maxPayment = customer.getAmount();
                }
                if (customer.getAmount() < minPayment) {
                    minPayment = customer.getAmount();
                }
                validCustomersCount++;
            }
        }

        if (validCustomersCount > 0) {
            double avgPayment = totalPayment / validCustomersCount;
            JOptionPane.showMessageDialog(null, "Average Payment: " + avgPayment + "\nMaximum Payment: " + maxPayment + "\nMinimum Payment: " + minPayment);
        } else {
            JOptionPane.showMessageDialog(null, "No valid payments were made.");
        }
    }
	// end of the displayStat method


	// write data to file, the credit card number should be encrypted
	// using one-way hash method in the Hashing class
    public static void writeToFile(){
    	try {
            PrintWriter writer = new PrintWriter(new FileWriter("Customer.txt"));
            for (Customer customer : customers) {
                if (customer != null && isValidCard(Long.toString(customer.getCard().getNumber()))) {
                    String encryptedNumber = createHashCode(Long.toString(customer.getCard().getNumber()));
                    writer.println(customer.toString());
                    writer.println("Encrypted Card Number: " + encryptedNumber + "\n");
                }
            }
            writer.close();
            JOptionPane.showMessageDialog(null, "Customer data has been written to file successfully.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing customer data to file: " + e.getMessage());
        }
    }
    // end of the writeToFile method


	// the main entry method of the program that will get data from user and
	// perform the business logic
	public static void main(String[] args) {

		hashing = new HashCode();
		validating = new  Validation();
               // input the number of customers and stor it into variable n
              // must hold the number of customers based on the user input
		try {
            int n = Integer.parseInt(JOptionPane.showInputDialog("Enter the maximum number of customers:"));
            customers = new Customer[n];

            int customerId = 1;
            while (customerId <= n) {
                String fName = null;
                while (true) {
                    try {
                        fName = JOptionPane.showInputDialog("Enter customer number " + customerId + "'s first name:");
                        if (fName == null || fName.trim().isEmpty()) {
                            throw new IllegalArgumentException("First name cannot be empty.");
                        }
                        if (fName.matches(".*\\d+.*")) {
                            throw new IllegalArgumentException("First name cannot contain numbers.");
                        }
                        break;
                    } catch (IllegalArgumentException e) {
                        JOptionPane.showMessageDialog(null, e.getMessage());
                    }
                }

                String lName = null;
                while (true) {
                    try {
                        lName = JOptionPane.showInputDialog("Enter customer number " + customerId + "'s last name:");
                        if (lName == null || lName.trim().isEmpty()) {
                            throw new IllegalArgumentException("Last name cannot be empty.");
                        }
                        if (lName.matches(".*\\d+.*")) {
                            throw new IllegalArgumentException("Last name cannot contain numbers.");
                        }
                        break;
                    } catch (IllegalArgumentException e) {
                        JOptionPane.showMessageDialog(null, e.getMessage());
                    }
                }

                double amount = Double.parseDouble(JOptionPane.showInputDialog("Enter payment amount for customer number " + customerId + ":"));
                long cardNumber = Long.parseLong(JOptionPane.showInputDialog("Enter credit card number for customer number " + customerId + ":"));
                String expDate = JOptionPane.showInputDialog("Enter credit card expiration date for customer number " + customerId + ":");

                CreditCard card = new CreditCard(cardNumber, expDate);
                Customer customer = new Customer(fName, lName, customerId, amount, card);
                addCustomer(customer);

                customerId++;

                int option = JOptionPane.showConfirmDialog(null, "Do you want to add another customer?", "Continue",
                        JOptionPane.YES_NO_OPTION);
                if (option != JOptionPane.YES_OPTION) {
                    break;
                }
            }

            displayStat();
            writeToFile();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input format.");
        }
    }
	}

