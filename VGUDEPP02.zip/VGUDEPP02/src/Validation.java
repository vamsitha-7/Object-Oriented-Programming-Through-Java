import javax.swing.JOptionPane;

public class Validation {


  // Return true if the card number is valid, otherwise returns false, this method is already implemented
  public boolean aValidNumber(String n) {
	        try {
	            // Check for empty or invalid entries
	            if (n == null || n.trim().isEmpty()) {
	                JOptionPane.showMessageDialog(null, "Credit card number cannot be empty or null.");
	                return false;
	            }

	            // Remove any space characters
	            String numberString = n.replaceAll("\\s+", "");

	            // Convert the credit card number to an array of integers
	            int[] digits = new int[numberString.length()];
	            for (int i = 0; i < numberString.length(); i++) {
	                digits[i] = Character.getNumericValue(numberString.charAt(i));
	            }

	            // Apply the Luhn algorithm
	            int sum = 0;
	            boolean alternate = false;
	            for (int i = digits.length - 1; i >= 0; i--) {
	                int digit = digits[i];
	                if (alternate) {
	                    digit *= 2;
	                    if (digit > 9) {
	                        digit = digit % 10 + 1;
	                    }
	                }
	                sum += digit;
	                alternate = !alternate;
	            }

	            // Check if the sum is divisible by 10
	            boolean isValid = sum % 10 == 0;

	            if (!isValid) {
	                JOptionPane.showMessageDialog(null, "Invalid credit card number.");
	            }

	            return isValid;
	        } catch (NumberFormatException e) {
	            JOptionPane.showMessageDialog(null, "Invalid input format for credit card number.");
	            return false;
	        }
	    }
	  // end of aValidNumber method

  //get the sum of even places numbers, Starting from the second digit from right
  private int totalEevenNumbers(long number) {
	  int sum = 0;
      boolean alternate = false;
      while (number > 0) {
          if (!alternate) {
              int digit = (int) (number % 10);
              sum += singleDigit(digit * 2);
          }
          alternate = !alternate;
          number /= 10;
      }
      return sum;
  }// end of totalEevenNumbers method

  // Return the same number if it is a single digit, otherwise, return the sum of
  // the two digits in this number
  private int singleDigit(int number) {
	  if (number < 10) {
          return number;
      } else {
          return number % 10 + number / 10;
      }
  } // end of singleDigit method



  // Return the sum of odd place digits in number
  private int totalOddNumbers(long number) {

    int result = 0;
    boolean alternate = true;
    while (number > 0) {
        if (alternate) {
            result += (int) (number % 10);
        }
        alternate = !alternate;
        number /= 10;
    }
    return result;
}// end of totalOddNumbers method

  // Return true if the digit d is a prefix for number
  private boolean prefixCheck(long number, int d) {
	  String numStr = Long.toString(number);
	    String prefix = numStr.substring(0, String.valueOf(d).length());
	    return prefix.equals(String.valueOf(d));
  }// end of prefixCheck method


  // Return the number of digits in this number parameter
  private int numLength(long number) {
	  return String.valueOf(number).length();
  }// end of numLength method

  // Return the first k number of digits from number, which is either a first digit or first two digits
  // Depending on the card type
  private long numPrefix(long number, int k) {
	  String numStr = Long.toString(number);
	  if (numStr.length() >= k) {
	        return Long.parseLong(numStr.substring(0, k));
	    } else {
	        // Handle the case where the number is too short
	        return number;
	    }
  }// end of numPrefix method

}// end of the class
