

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Parser {
	
	// class variables 
	private Pattern itemPattern;
	private ArrayList<Product>  products;
	
	// define the class constructor 
	public Parser(String itemRegex) {
		// create the Pattern object from itemRegex
		this.itemPattern = Pattern.compile(itemRegex);
	}// end of the constructor
	
	// reads a text file whose name is given as a parameter
	// and returns the file contents in a string format
	private String getFileContents(String fileName) throws FileNotFoundException {
		// Use the scanner to read the data from the fileName parameter
		
		// create one string input of the file
		
		// close the scanner
		
		// return the string not null
		StringBuilder content = new StringBuilder();
        File file = new File(fileName);
        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                content.append(scanner.nextLine()).append("\n");
            }
        }
        return content.toString();
	}// end of getFileContent method
	
	// parses a text file whose name is given as a parameter 
	// and returns athe parsed products as Product objects stored in an array list
	public ArrayList<Product> parse(String fileName) throws FileNotFoundException {
		// call getFileContent to retrieve the file contents
		
		// define the Pattern object
		
		// define ArrayList (products) to be used to hold the Product objects
		
		// declare a temporary Product object(productObject) 
		
		// erturn the array list of the Product objects
		String contents = getFileContents(fileName);
        Matcher matcher = itemPattern.matcher(contents);
        products = new ArrayList<>();

        while (matcher.find()) {
            String title = matcher.group(1).trim(); // Using trim() to remove any leading/trailing whitespace
            String price = matcher.group(2).trim();
            products.add(new Product(title, price));
        }
        return products;
	}// end of parse method
}

