

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;



public class RegexApplication {
	
	// declare the class variables
	private static final String inputFileName 		= "RetailStore.txt";
	private static final String outputFileName 		= "matcherout.txt";
	
	//private static String itemRegex = null;
	//private static Parser parser = null; 

	// This method receives a text string and stores it in an output file
	private static void writeToFile(String productsString) throws FileNotFoundException {
		// Define a PrintWriter object to store the program output
		try (PrintWriter writer = new PrintWriter(new File(outputFileName))) {
            writer.print(productsString);
        }
		// write data to file
	
		// Close the file
	
	}// end of writeToFile method

	
	//This method receives a collection of product objects stored in an array list as a parameter
	// and it returns the concatenate the products� information (title and retailPrice) into a single string
	private static String getProductsAsString(ArrayList<Product> products) {
		// Declare a string variable that is used to concatenate the products' information into a string
			
		
		// add to the output the size of the array list, the number of the Product objects  
		
		// retrun the output as a string
		StringBuilder result = new StringBuilder();
        for (Product product : products) {
            result.append(product.toString()).append("\n");
        }
        result.append("Number of Items = ").append(products.size());
        return result.toString();
	}// end of getProductsAsString method
	
	
	// This the the entry method that uses the created classes and methods to run the program 
	public static void main(String[] args) throws FileNotFoundException {
		// Define the 'itemRegex' regex for the Product Title and Suggested Retail Price
		
		// Create a Parser object
		
		// use the Parser object to call method parse() to parse the content of the retail store file and returns the ArrayList of the Product objects
		
		
		// call method getProductsAsString() to return the string of the ArrayList
		
		// call writeToFile() to store the program output to a file
		
		// display the output using JOptionPane.showMessageDialog
		try {
            String itemRegex = "title=\"(.*?)\".*?Suggested Retail Price: \\$(\\d{2,}\\.\\d{2})";
            Parser parser = new Parser(itemRegex);
            ArrayList<Product> products = parser.parse(inputFileName);
            String productsAsString = getProductsAsString(products);
            writeToFile(productsAsString);
            JTextArea textArea = new JTextArea(20, 50);  // Set the JTextArea dimensions
            textArea.setText(productsAsString);
            textArea.setEditable(false);

            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
            scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

            JOptionPane.showMessageDialog(null, scrollPane, "Product List", JOptionPane.INFORMATION_MESSAGE);

        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error: File not found.");
        } catch (Exception e) {
            e.printStackTrace();
        }
	}// end of main method

}
